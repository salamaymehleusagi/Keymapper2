plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.keymapper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.keymapper"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/DEPENDENCIES",
                "META-INF/AL2.0", "META-INF/LGPL2.1"
            )
        }
    }
}

dependencies {
    // Yerleşik ADB istemcisi (pair / connect / shell) – Shizuku YOK
    implementation("com.github.MuntashirAkon:libadb-android:3.1.0")
    implementation("org.conscrypt:conscrypt-android:2.5.3")               // ADB TLS (kablosuz hata ayıklama)
}
