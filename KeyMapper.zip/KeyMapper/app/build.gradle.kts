plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.keymapper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.keymapper"
        minSdk = 26          // dispatchGesture(continueStroke) + pointer capture
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildFeatures { aidl = true }
    buildTypes {
        release {
            isMinifyEnabled = false
            // Debug anahtarıyla imzalanır -> assembleRelease çıktısı direkt kurulabilir APK olur
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
