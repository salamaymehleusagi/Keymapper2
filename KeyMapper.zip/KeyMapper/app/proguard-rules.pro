# ProGuard kuralları (minify kapalı)
