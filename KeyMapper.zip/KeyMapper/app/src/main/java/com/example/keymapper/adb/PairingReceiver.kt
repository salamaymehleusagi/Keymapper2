package com.example.keymapper.adb

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import com.example.keymapper.data.Prefs

/**
 * Eşleme kodu girişi için bildirim (RemoteInput). Android'in "Eşleme koduyla eşle" penceresi
 * uygulamadan çıkınca kapandığı için, kodu bildirimin içine yazarak eşlersin:
 *   "37123 482915"  (eşleme portu + 6 haneli kod)
 */
object PairingNotifier {
    const val KEY = "pair_input"
    private const val CH = "km_pair"
    private const val ID = 77

    private fun nm(c: Context): NotificationManager {
        val m = c.getSystemService(NotificationManager::class.java)
        m.createNotificationChannel(NotificationChannel(CH, "ADB eşleme", NotificationManager.IMPORTANCE_HIGH))
        return m
    }

    fun showInput(c: Context) {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(c, 1, Intent(c, PairingReceiver::class.java), flags)
        val ri = RemoteInput.Builder(KEY).setLabel("Port ve 6 haneli kod (ör. 37123 482915)").build()
        val action = Notification.Action.Builder(
            Icon.createWithResource(c, android.R.drawable.ic_menu_send), "Eşle", pi
        ).addRemoteInput(ri).build()
        val n = Notification.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("KeyMapper: ADB eşleme")
            .setContentText("Ayarlar > Kablosuz hata ayıklama > Eşleme koduyla eşle'yi aç, sonra buraya yaz")
            .addAction(action)
            .setOngoing(true)
            .build()
        nm(c).notify(ID, n)
    }

    fun showResult(c: Context, msg: String) {
        val n = Notification.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("KeyMapper: ADB")
            .setContentText(msg)
            .setAutoCancel(true)
            .build()
        nm(c).notify(ID, n)
    }
}

class PairingReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val text = RemoteInput.getResultsFromIntent(i)?.getCharSequence(PairingNotifier.KEY)?.toString()
            ?: return
        val nums = Regex("\\d+").findAll(text).map { it.value }.toList()
        if (nums.size < 2) { PairingNotifier.showResult(c, "Biçim: port boşluk kod (ör. 37123 482915)"); return }
        val pr = goAsync()
        val app = c.applicationContext
        Thread {
            val msg = try {
                AdbHelper.pair(app, Prefs.lastHost(app), nums[0].toInt(), nums[1])
                "Eşleme başarılı. Şimdi uygulamadan 'Bağlan'a bas."
            } catch (e: Exception) {
                "Eşleme hatası: ${e.message}"
            }
            PairingNotifier.showResult(app, msg)
            pr.finish()
        }.start()
    }
}
