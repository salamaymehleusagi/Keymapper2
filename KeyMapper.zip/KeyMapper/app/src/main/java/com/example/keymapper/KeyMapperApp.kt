package com.example.keymapper

import android.app.Application
import org.conscrypt.Conscrypt
import java.security.Security

class KeyMapperApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Kablosuz hata ayıklama (TLS 1.3) için Conscrypt'i birinci sağlayıcı yap
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
    }
}
