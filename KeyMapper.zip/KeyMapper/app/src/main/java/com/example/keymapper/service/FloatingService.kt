package com.example.keymapper.service

import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import com.example.keymapper.adb.AdbHelper
import com.example.keymapper.adb.InjectorClient
import com.example.keymapper.core.BackendSelector
import com.example.keymapper.core.InputEngine
import com.example.keymapper.core.TouchBackend
import com.example.keymapper.data.Prefs
import com.example.keymapper.data.ProfileRepository
import com.example.keymapper.model.Binding
import com.example.keymapper.model.ElementType
import com.example.keymapper.model.MappingElement
import com.example.keymapper.model.Profile
import com.example.keymapper.model.StickSource
import com.example.keymapper.ui.CaptureView
import com.example.keymapper.ui.EditorView
import kotlin.math.abs

/**
 * Yüzen ikon + düzenleme HUD'ı + oyun modu (capture penceresi + girdi motoru).
 *  İkon tıkla  -> editör aç/kapat (oyun modundaysa durdurup editörü açar)
 *  Editör      -> [+ Ekle] [▶ Oyna] [💾 Kaydet] [✕ Kapat]
 */
class FloatingService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var repo: ProfileRepository
    private lateinit var engine: InputEngine
    private val main = Handler(Looper.getMainLooper())

    private var icon: TextView? = null
    private var iconLp: LayoutParams? = null
    private var editorRoot: FrameLayout? = null
    private var editorView: EditorView? = null
    private var capture: CaptureView? = null

    private var profile = Profile("Default")
    private var playing = false
    private var lastPkg: String? = null

    override fun onBind(i: Intent?): IBinder? = null

    // ------------------------------------------------------------------ yaşam döngüsü
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        repo = ProfileRepository(this)
        engine = InputEngine { backend() }
        engine.onLockChanged = { setCapture(it) }
        startAsForeground()
        profile = repo.load(Prefs.activeProfile(this)) ?: Profile(Prefs.activeProfile(this))
        createIcon()

        KeyMapperAccessibilityService.onKey = { engine.onKey(it) }
        KeyMapperAccessibilityService.onForegroundPackage = { onForeground(it) }
        InjectorClient.onLost = { main.post { onInjectorLost() } }
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onDestroy() {
        stopPlay(); hideEditor()
        icon?.let { runCatching { wm.removeView(it) } }
        KeyMapperAccessibilityService.onKey = null
        KeyMapperAccessibilityService.onForegroundPackage = null
        InjectorClient.onLost = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        updateScreenSize()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("km", "KeyMapper", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "km")
            .setContentTitle("KeyMapper çalışıyor")
            .setContentText("Yüzen ikona dokunarak düzenleyin")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ------------------------------------------------------------------ yardımcılar
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val overlayType = LayoutParams.TYPE_APPLICATION_OVERLAY

    /** ADB bağlıysa ADB, değilse Erişilebilirlik; ikisi de yoksa null. */
    private fun backend(): TouchBackend? = BackendSelector.backend()

    private fun updateScreenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            engine.screenW = b.width(); engine.screenH = b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            engine.screenW = m.widthPixels; engine.screenH = m.heightPixels
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun builder() = AlertDialog.Builder(
        ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert))

    private fun showDialog(b: AlertDialog.Builder): AlertDialog {
        val d = b.create()
        d.window?.setType(overlayType)
        d.show()
        return d
    }

    /** Enjektör soketi oyun sırasında koparsa: takılı girdileri bırak, yeniden bağlan / yeniden başlat. */
    private fun onInjectorLost() {
        if (!playing) return
        engine.releaseInputs()
        toast("Enjektör bağlantısı koptu, yeniden bağlanılıyor…")
        AdbHelper.io.execute {
            var ok = InjectorClient.connectBlocking(this)
            if (!ok && AdbHelper.connected) ok = AdbHelper.startInjector(this).first
            main.post {
                if (ok) toast("Enjektör yeniden bağlandı ✅")
                else toast("Enjektör kopuk: ana ekrandan ADB'yi bağla ve 'Enjektörü başlat'a bas")
            }
        }
    }

    // ------------------------------------------------------------------ oyuna göre otomatik profil
    private fun onForeground(pkg: String) {
        if (pkg == packageName || pkg == "com.android.systemui" || pkg.contains("inputmethod")) return
        lastPkg = pkg
        val name = Prefs.pkgProfile(this, pkg) ?: return
        if (name == profile.name) return
        val p = repo.load(name) ?: return
        profile = p
        Prefs.setActiveProfile(this, name)
        if (playing) { engine.stop(); engine.profile = p; engine.start() }
        toast("Profil yüklendi: $name")
    }

    // ------------------------------------------------------------------ yüzen ikon
    private fun createIcon() {
        val tv = TextView(this).apply {
            text = "🎮"; textSize = 22f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC37474F.toInt()) }
        }
        val lp = LayoutParams(dp(52), dp(52), overlayType,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(160)
        }
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = lp.x; iy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    if (moved) { lp.x = ix + dx; lp.y = iy + dy; wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onIconClick()
            }
            true
        }
        wm.addView(tv, lp); icon = tv; iconLp = lp
    }

    private fun bringIconToFront() {
        val tv = icon ?: return; val lp = iconLp ?: return
        runCatching { wm.removeView(tv) }; wm.addView(tv, lp)
    }

    private fun setIconPlaying(p: Boolean) {
        (icon?.background as? GradientDrawable)?.setColor(if (p) 0xCC2E7D32.toInt() else 0xCC37474F.toInt())
    }

    private fun onIconClick() {
        when {
            playing -> { stopPlay(); showEditor() }
            editorRoot != null -> hideEditor()
            else -> showEditor()
        }
    }

    // ------------------------------------------------------------------ editör HUD
    private fun showEditor() {
        if (editorRoot != null) return
        val ev = EditorView(this, profile)
        ev.onAdd = { x, y -> addDialog(x, y) }
        ev.onEdit = { editDialog(it) }
        ev.onRecordingDone = { toast("Makro kaydı bitti") }
        editorView = ev

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(0xAA000000.toInt())
            fun btn(t: String, a: () -> Unit) = addView(Button(context).apply {
                text = t; textSize = 12f; setOnClickListener { a() }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            btn("+ Ekle") { toast("Boş bir alana dokun") }
            btn("▶ Oyna") { saveProfile(); startPlay() }
            btn("💾 Kaydet") { saveProfile() }
            btn("✕ Kapat") { hideEditor() }
        }
        val root = FrameLayout(this).apply {
            addView(ev, FrameLayout.LayoutParams(-1, -1))
            addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        }
        val lp = LayoutParams(-1, -1, overlayType,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN or LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode = LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(root, lp)
        editorRoot = root
        bringIconToFront()
    }

    private fun hideEditor() {
        editorRoot?.let { runCatching { wm.removeView(it) } }
        editorRoot = null; editorView = null
    }

    private fun saveProfile() {
        repo.save(profile)
        Prefs.setActiveProfile(this, profile.name)
        lastPkg?.let { Prefs.setPkgProfile(this, it, profile.name) }   // oyun -> profil bağla
        toast("Kaydedildi: ${profile.name}" + (lastPkg?.let { " ($it)" } ?: ""))
    }

    // ------------------------------------------------------------------ eleman ekleme / düzenleme
    private fun addDialog(nx: Float, ny: Float) {
        val names = arrayOf("Tuş (Bas-Çek / Basılı tut)", "Joystick (WASD / analog)", "Kamera (Mouse Look / sağ analog)",
            "Makro (combo)", "Swipe / Drag", "Aimlock / Shiftlock tuşu")
        showDialog(builder().setTitle("Eleman ekle").setItems(names) { _, which ->
            val e = when (which) {
                0 -> MappingElement(type = ElementType.BUTTON, x = nx, y = ny, size = 0.05f)
                1 -> MappingElement(type = ElementType.JOYSTICK, x = nx, y = ny, size = 0.12f)
                2 -> MappingElement(type = ElementType.CAMERA, x = nx, y = ny, size = 0.25f, binding = "M:R")
                3 -> MappingElement(type = ElementType.MACRO, x = nx, y = ny, size = 0.05f)
                4 -> MappingElement(type = ElementType.SWIPE, x = nx, y = ny, size = 0.05f,
                    x2 = (nx + 0.2f).coerceAtMost(1f), y2 = ny)
                else -> MappingElement(type = ElementType.LOCK_TOGGLE, x = nx, y = ny, size = 0.04f,
                    binding = Binding.key(KeyEvent.KEYCODE_SHIFT_LEFT))
            }
            profile.elements.add(e)
            editorView?.invalidate()
            editDialog(e)
        })
    }

    private fun editDialog(el: MappingElement) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
        }
        lateinit var dlg: AlertDialog

        fun info(t: String) = col.addView(TextView(this).apply { text = t; setPadding(0, dp(8), 0, 0) })
        /** Tıklayınca diyaloğu kapatır, işlemi yapar. */
        fun action(t: String, a: () -> Unit) = col.addView(Button(this).apply {
            text = t; setOnClickListener { dlg.dismiss(); a() }
        })
        /** Ayarlar değişince diyaloğu yeniden açarak etiketleri günceller. */
        fun toggle(t: String, a: () -> Unit) = action(t) { a(); editDialog(el) }
        fun seek(title: String, min: Float, max: Float, v: Float, dec: Int, set: (Float) -> Unit) {
            val t = TextView(this).apply { text = "$title: ${"%.${dec}f".format(v)}" }
            val sb = SeekBar(this).apply {
                this.max = 100
                progress = (((v - min) / (max - min)) * 100).toInt().coerceIn(0, 100)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                        val nv = min + (max - min) * p / 100f
                        set(nv); t.text = "$title: ${"%.${dec}f".format(nv)}"; editorView?.invalidate()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            col.addView(t); col.addView(sb)
        }
        fun delaySeek() = seek("Gecikme (ms)", 0f, 1000f, el.delayMs.toFloat(), 0) { el.delayMs = it.toLong() }

        info("Tür: ${el.type}   |   Tuş: ${Binding.label(el.binding)}")
        seek("Boyut", 0.02f, 0.5f, el.size, 2) { el.size = it }
        when (el.type) {
            ElementType.JOYSTICK -> {
                seek("Hassasiyet (menzil)", 0.3f, 1.5f, el.sensitivity, 2) { el.sensitivity = it }
                action("Kaynak: ${el.stick.label}") { pickStick(el) }
            }
            ElementType.CAMERA -> {
                seek("Kamera hassasiyeti", 0.1f, 4f, el.sensitivity, 2) { el.sensitivity = it }
                seek("ADS çarpanı (nişan)", 0.1f, 1.5f, el.adsSens, 2) { el.adsSens = it }
                action("ADS tuşu: ${Binding.label(el.binding)}") { pickBinding(el) }
            }
            ElementType.SWIPE -> {
                seek("Süre (ms)", 100f, 1500f, el.durationMs.toFloat(), 0) { el.durationMs = it.toLong() }
                delaySeek()
                info("Bitiş noktasını editörde turkuaz noktayı sürükleyerek ayarla.")
                action("Tetik tuşu: ${Binding.label(el.binding)}") { pickBinding(el) }
            }
            ElementType.MACRO -> {
                info("Adım sayısı: ${el.steps.size}")
                seek("Adımlar arası bekleme (ms)", 0f, 1000f, el.gapMs.toFloat(), 0) { el.gapMs = it.toLong() }
                delaySeek()
                action("Adımları kaydet (noktalara dokun)") {
                    el.steps.clear(); editorView?.recording = el; editorView?.invalidate()
                    toast("Noktalara dokun; bitirince makro simgesine dokun")
                }
                toggle("Aynı anda: ${if (el.parallel) "AÇIK" else "kapalı"}") { el.parallel = !el.parallel }
                toggle("Tuş basılıyken tekrarla: ${if (el.loop) "AÇIK" else "kapalı"}") { el.loop = !el.loop }
                action("Tetik tuşu: ${Binding.label(el.binding)}") { pickBinding(el) }
            }
            ElementType.LOCK_TOGGLE -> {
                info("Bu tuş fare kilidini (Aimlock/Shiftlock) açıp kapatır: imleç merkezde sabitlenir, " +
                    "kamera hassasiyeti uygulanır.")
                action("Tuş: ${Binding.label(el.binding)}") { pickBinding(el) }
            }
            ElementType.BUTTON -> {
                toggle("Mod: ${if (el.hold) "Basılı Tut (Hold)" else "Bas-Çek (Tap)"}") { el.hold = !el.hold }
                if (!el.hold) {
                    seek("Dokunma süresi (ms)", 10f, 300f, el.tapMs.toFloat(), 0) { el.tapMs = it.toLong() }
                    toggle("Turbo (basılıyken tekrarla): ${if (el.turbo) "AÇIK" else "kapalı"}") { el.turbo = !el.turbo }
                    if (el.turbo)
                        seek("Turbo aralığı (ms)", 30f, 500f, el.intervalMs.toFloat(), 0) { el.intervalMs = it.toLong() }
                }
                delaySeek()
                action("Tuşu ata: ${Binding.label(el.binding)}") { pickBinding(el) }
            }
        }

        dlg = showDialog(builder().setTitle("Ayarlar").setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("Tamam", null)
            .setNeutralButton("Sil") { _, _ -> profile.elements.remove(el); editorView?.invalidate() })
    }

    private fun pickStick(el: MappingElement) {
        val all = StickSource.values()
        showDialog(builder().setTitle("Joystick kaynağı")
            .setItems(all.map { it.label }.toTypedArray()) { _, i -> el.stick = all[i]; editorView?.invalidate() })
    }

    private fun pickBinding(el: MappingElement) {
        val items = arrayOf("Tuşa bas (klavye / gamepad)…", "Kombinasyona tuş ekle (ör. Shift+A)…",
            "Fare sol tık", "Fare sağ tık", "Fare orta tık", "Temizle")
        showDialog(builder().setTitle("Tuş ata").setItems(items) { _, i ->
            when (i) {
                0 -> captureKey(el, false)
                1 -> captureKey(el, true)
                2 -> el.binding = "M:L"
                3 -> el.binding = "M:R"
                4 -> el.binding = "M:M"
                5 -> el.binding = ""
            }
            editorView?.invalidate()
        })
    }

    private fun captureKey(el: MappingElement, append: Boolean) {
        val d = builder().setTitle(if (append) "Kombinasyona eklenecek tuşa bas" else "Bir tuşa bas")
            .setMessage("Klavye veya gamepad tuşuna bas…")
            .setNegativeButton("İptal", null).create()
        d.window?.setType(overlayType)
        d.setOnKeyListener { dd, code, ev ->
            if (ev.action == KeyEvent.ACTION_DOWN && code != KeyEvent.KEYCODE_BACK) {
                val k = Binding.key(code)
                el.binding = if (append && el.binding.isNotEmpty()) el.binding + "+" + k else k
                editorView?.invalidate(); dd.dismiss(); true
            } else false
        }
        d.show()
    }

    // ------------------------------------------------------------------ oyun modu
    private fun startPlay() {
        // Önce ADB enjektörünü tercih et: bağlı değilse bağlanmayı, gerekirse ADB ile yeniden
        // başlatmayı dene (arka plan kuyruğunda). Hiçbiri olmazsa BackendSelector Erişilebilirliğe düşer.
        if (!InjectorClient.isConnected) {
            toast("Enjektör aranıyor…")
            AdbHelper.io.execute {
                var ok = InjectorClient.connectBlocking(this)
                if (!ok && AdbHelper.connected) ok = AdbHelper.startInjector(this).first
                main.post {
                    if (BackendSelector.mode() == BackendSelector.Mode.NONE)
                        toast("Lütfen ADB veya Erişilebilirlik izni verin (ADB: ana ekrandan eşle/bağla + Enjektörü başlat)")
                    else startPlayNow()
                }
            }
            return
        }
        startPlayNow()
    }

    private fun startPlayNow() {
        hideEditor()
        updateScreenSize()
        engine.profile = profile
        engine.start()
        addCapture()
        playing = true; setIconPlaying(true)
        toast("Oyun modu AÇIK (${BackendSelector.label()}) — ikona dokunarak düzenleyiciye dön")
    }

    private fun stopPlay() {
        if (!playing) return
        engine.stop()
        capture?.let { runCatching { it.releasePointerCapture() }; runCatching { wm.removeView(it) } }
        capture = null; playing = false; setIconPlaying(false)
    }

    /** 1x1 px, dokunulamaz ama odaklanabilir pencere: tuş / gamepad / fare girdisini toplar. */
    private fun addCapture() {
        val v = CaptureView(this, engine)
        val lp = LayoutParams(1, 1, overlayType,
            LayoutParams.FLAG_NOT_TOUCHABLE or LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
            .apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(v, lp)
        capture = v
        v.post { v.requestFocus(); if (engine.locked) v.requestPointerCapture() }
    }

    /** Aimlock/Shiftlock: fare imlecini gizleyip merkezde kilitler (Pointer Capture). */
    private fun setCapture(locked: Boolean) {
        val v = capture ?: return
        if (locked) { v.requestFocus(); v.requestPointerCapture() } else v.releasePointerCapture()
    }
}
