package com.example.keymapper.core

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import com.example.keymapper.model.ElementType
import com.example.keymapper.model.MappingElement
import com.example.keymapper.model.Profile
import com.example.keymapper.model.StickSource
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Girdi motoru: klavye / fare / gamepad olaylarını profildeki elemanlara göre
 * sanal dokunuşlara (TouchBackend) çevirir. Tüm çağrılar ana thread'dedir.
 */
class InputEngine(private val backendProvider: () -> TouchBackend?) {

    var profile = Profile("Default")
    var screenW = 1080
    var screenH = 1920
    /** Aimlock/Shiftlock değişince çağrılır (fare yakalamayı aç/kapat). */
    var onLockChanged: ((Boolean) -> Unit)? = null

    var running = false; private set
    var locked = false; private set

    private val h = Handler(Looper.getMainLooper())

    // --- parmak (pointer) id havuzu: serbest kalan id'ler kuyruğun sonuna gider ---
    private val free = ArrayDeque<Int>()
    private val allocated = HashSet<Int>()
    private fun resetPool() { free.clear(); free.addAll((0..9).toList()); allocated.clear() }
    private fun alloc(): Int? = free.removeFirstOrNull()?.also { allocated.add(it) }
    private fun release(id: Int) { if (allocated.remove(id)) free.addLast(id) }

    private val pointerOf = HashMap<String, Int>()      // eleman id -> parmak id (buton/joystick)
    private class Cam(var id: Int, var x: Float, var y: Float)
    private val cam = HashMap<String, Cam>()
    private val camIdle = HashMap<String, Runnable>()
    private val macroToken = HashMap<String, Any>()

    private val keysDown = HashSet<Int>()
    private val held = HashSet<String>()                // basılı binding'ler
    private val synth = HashSet<Int>()                  // eksenden türetilen sanal tuşlar
    private var lx = 0f; private var ly = 0f; private var rx = 0f; private var ry = 0f
    private var lastButtons = 0

    init { resetPool() }

    private fun minDim() = min(screenW, screenH).toFloat()

    // ------------------------------------------------------------------ yaşam döngüsü
    fun start() {
        resetPool()
        running = true
        val hasCam = profile.elements.any { it.type == ElementType.CAMERA }
        val hasToggle = profile.elements.any { it.type == ElementType.LOCK_TOGGLE }
        locked = hasCam && !hasToggle        // sadece kamera varsa otomatik kilitli başla
        onLockChanged?.invoke(locked)
        h.post(ticker)
    }

    fun stop() {
        running = false
        h.removeCallbacksAndMessages(null)
        releaseAll()
        keysDown.clear(); held.clear(); synth.clear(); macroToken.clear()
        lx = 0f; ly = 0f; rx = 0f; ry = 0f; lastButtons = 0
    }

    private fun releaseAll() {
        val be = backendProvider()
        allocated.toList().forEach { be?.up(it) }
        pointerOf.clear(); cam.clear(); camIdle.clear()
        resetPool()
    }

    // ------------------------------------------------------------------ klavye / gamepad tuşları
    fun onKey(e: KeyEvent): Boolean {
        if (!running) return false
        val down = e.action == KeyEvent.ACTION_DOWN
        if (down && e.repeatCount > 0) return isBoundKey(e.keyCode)
        if (e.action != KeyEvent.ACTION_DOWN && e.action != KeyEvent.ACTION_UP) return false
        return keyCode(e.keyCode, down)
    }

    private fun keyCode(code: Int, down: Boolean): Boolean {
        if (down) keysDown.add(code) else keysDown.remove(code)
        val a = onBinding("K:$code", down)
        val b = refreshKeyJoysticks(code)
        return a || b
    }

    private fun joyKeys(s: StickSource): IntArray? = when (s) {
        StickSource.WASD -> intArrayOf(KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D)
        StickSource.ARROWS -> intArrayOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT)
        else -> null
    }

    private fun isBoundKey(code: Int) = profile.elements.any {
        it.binding == "K:$code" || (it.type == ElementType.JOYSTICK && joyKeys(it.stick)?.contains(code) == true)
    }

    private fun refreshKeyJoysticks(code: Int): Boolean {
        var used = false
        for (el in profile.elements) {
            if (el.type != ElementType.JOYSTICK) continue
            val k = joyKeys(el.stick) ?: continue
            if (!k.contains(code)) continue
            used = true
            // k = [yukarı, sol, aşağı, sağ]
            val vx = (if (keysDown.contains(k[3])) 1f else 0f) - (if (keysDown.contains(k[1])) 1f else 0f)
            val vy = (if (keysDown.contains(k[2])) 1f else 0f) - (if (keysDown.contains(k[0])) 1f else 0f)
            updateJoystick(el, vx, vy)
        }
        return used
    }

    // ------------------------------------------------------------------ tuş -> eleman
    private fun onBinding(b: String, down: Boolean): Boolean {
        if (down) held.add(b) else held.remove(b)
        var consumed = false
        for (el in profile.elements) {
            if (el.binding.isEmpty() || el.binding != b) continue
            consumed = true
            when (el.type) {
                ElementType.BUTTON -> if (down) buttonDown(el) else buttonUp(el)
                ElementType.MACRO -> if (down) {
                    val t = Any(); macroToken[el.id] = t; runMacro(el, 0, t)
                }
                ElementType.SWIPE -> if (down) animateSwipe(
                    el.x * screenW, el.y * screenH, el.x2 * screenW, el.y2 * screenH, el.durationMs
                )
                ElementType.LOCK_TOGGLE -> if (down) toggleLock()
                else -> {}   // CAMERA: ADS durumu 'held' kümesinden okunur
            }
        }
        return consumed
    }

    private fun buttonDown(el: MappingElement) {
        if (pointerOf.containsKey(el.id)) return
        val be = backendProvider() ?: return
        val id = alloc() ?: return
        be.down(id, el.x * screenW, el.y * screenH)
        pointerOf[el.id] = id
    }

    private fun buttonUp(el: MappingElement) {
        pointerOf.remove(el.id)?.let { backendProvider()?.up(it); release(it) }
    }

    // ------------------------------------------------------------------ sanal joystick
    private fun updateJoystick(el: MappingElement, vx: Float, vy: Float) {
        val be = backendProvider() ?: return
        val mag = hypot(vx, vy)
        val id = pointerOf[el.id]
        if (mag == 0f) {
            if (id != null) { be.up(id); release(id); pointerOf.remove(el.id) }
            return
        }
        val k = if (mag > 1f) 1f / mag else 1f           // çapraz hız normalizasyonu
        val r = el.size * minDim() * el.sensitivity
        val cx = el.x * screenW; val cy = el.y * screenH
        val tx = cx + vx * k * r; val ty = cy + vy * k * r
        if (id == null) {
            val nid = alloc() ?: return
            be.down(nid, cx, cy); pointerOf[el.id] = nid
            be.move(nid, tx, ty)
        } else be.move(id, tx, ty)
    }

    // ------------------------------------------------------------------ kamera (Mouse Look / sağ analog)
    private fun adsFactor(el: MappingElement) =
        if (el.binding.isNotEmpty() && held.contains(el.binding)) el.adsSens else 1f

    /**
     * Kamera bölgesinde bir parmak sürükler. Parmak bölge dışına çıkınca bırakılıp
     * merkezden yeniden basılır; böylece sınırsız 360° dönüş sağlanır.
     */
    private fun cameraMove(el: MappingElement, dx: Float, dy: Float) {
        val be = backendProvider() ?: return
        val cx = el.x * screenW; val cy = el.y * screenH; val r = el.size * minDim()
        var st = cam[el.id]
        if (st == null) {
            val id = alloc() ?: return
            be.down(id, cx, cy); st = Cam(id, cx, cy); cam[el.id] = st
        }
        st.x += dx; st.y += dy
        if (hypot(st.x - cx, st.y - cy) > r) {
            be.up(st.id); release(st.id); cam.remove(el.id)
            val id = alloc() ?: return
            be.down(id, cx, cy); cam[el.id] = Cam(id, cx, cy)
            return
        }
        be.move(st.id, st.x, st.y)
        camIdle[el.id]?.let { h.removeCallbacks(it) }
        val idle = Runnable { cam.remove(el.id)?.let { c -> be.up(c.id); release(c.id) } }
        camIdle[el.id] = idle
        h.postDelayed(idle, 120)                          // hareket durunca parmağı kaldır
    }

    private fun releaseCameras() {
        val be = backendProvider()
        cam.values.forEach { be?.up(it.id); release(it.id) }
        cam.clear()
    }

    /** Sağ analog çubukla kamera döndürme için periyodik tick. */
    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            if (rx != 0f || ry != 0f) {
                for (el in profile.elements) if (el.type == ElementType.CAMERA)
                    cameraMove(el, rx * SPEED * DT * el.sensitivity * adsFactor(el),
                        ry * SPEED * DT * el.sensitivity * adsFactor(el))
            }
            h.postDelayed(this, 16)
        }
    }

    // ------------------------------------------------------------------ Aimlock / Shiftlock
    fun toggleLock() {
        locked = !locked
        if (!locked) releaseCameras()
        onLockChanged?.invoke(locked)
    }

    // ------------------------------------------------------------------ fare (pointer capture)
    /** CaptureView.onCapturedPointerEvent -> göreli fare hareketi + tuşlar. */
    fun onCapturedMouse(ev: MotionEvent): Boolean {
        if (!running) return false
        val bs = ev.buttonState
        val changed = bs xor lastButtons
        if (changed != 0) {
            val map = listOf(
                MotionEvent.BUTTON_PRIMARY to "M:L",
                MotionEvent.BUTTON_SECONDARY to "M:R",
                MotionEvent.BUTTON_TERTIARY to "M:M"
            )
            for ((mask, name) in map) if ((changed and mask) != 0) onBinding(name, (bs and mask) != 0)
            lastButtons = bs
        }
        var dx = ev.x; var dy = ev.y
        for (i in 0 until ev.historySize) { dx += ev.getHistoricalX(i); dy += ev.getHistoricalY(i) }
        if (dx != 0f || dy != 0f) {
            for (el in profile.elements) if (el.type == ElementType.CAMERA) {
                val f = el.sensitivity * adsFactor(el)
                cameraMove(el, dx * f, dy * f)
            }
        }
        return true
    }

    // ------------------------------------------------------------------ gamepad eksenleri
    private fun dz(v: Float) = if (abs(v) < 0.12f) 0f else v

    fun onGenericMotion(ev: MotionEvent): Boolean {
        if (!running) return false
        val joystick = (ev.source and android.view.InputDevice.SOURCE_JOYSTICK) ==
            android.view.InputDevice.SOURCE_JOYSTICK
        if (!joystick || ev.action != MotionEvent.ACTION_MOVE) return false

        lx = dz(ev.getAxisValue(MotionEvent.AXIS_X)); ly = dz(ev.getAxisValue(MotionEvent.AXIS_Y))
        val zx = dz(ev.getAxisValue(MotionEvent.AXIS_Z)); val zy = dz(ev.getAxisValue(MotionEvent.AXIS_RZ))
        rx = if (zx != 0f || zy != 0f) zx else dz(ev.getAxisValue(MotionEvent.AXIS_RX))
        ry = if (zx != 0f || zy != 0f) zy else dz(ev.getAxisValue(MotionEvent.AXIS_RY))

        // Analog tetikler ve HAT (D-Pad) eksenleri -> sanal tuş olayları
        val lt = maxOf(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))
        val rt = maxOf(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))
        val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X); val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        synthKey(KeyEvent.KEYCODE_BUTTON_L2, lt > 0.5f)
        synthKey(KeyEvent.KEYCODE_BUTTON_R2, rt > 0.5f)
        synthKey(KeyEvent.KEYCODE_DPAD_LEFT, hx < -0.5f)
        synthKey(KeyEvent.KEYCODE_DPAD_RIGHT, hx > 0.5f)
        synthKey(KeyEvent.KEYCODE_DPAD_UP, hy < -0.5f)
        synthKey(KeyEvent.KEYCODE_DPAD_DOWN, hy > 0.5f)

        for (el in profile.elements) if (el.type == ElementType.JOYSTICK) when (el.stick) {
            StickSource.LEFT_STICK -> updateJoystick(el, lx, ly)
            StickSource.RIGHT_STICK -> updateJoystick(el, rx, ry)
            else -> {}
        }
        return true
    }

    private fun synthKey(code: Int, down: Boolean) {
        if (down == synth.contains(code)) return
        if (down) synth.add(code) else synth.remove(code)
        keyCode(code, down)
    }

    // ------------------------------------------------------------------ makro / swipe
    private fun runMacro(el: MappingElement, i: Int, token: Any) {
        if (macroToken[el.id] !== token) return
        if (i >= el.steps.size) {
            if (el.loop && held.contains(el.binding) && el.steps.isNotEmpty())
                h.postDelayed({ runMacro(el, 0, token) }, 100)
            else macroToken.remove(el.id)
            return
        }
        val s = el.steps[i]
        when (s.kind) {
            "TAP" -> tap(s.x * screenW, s.y * screenH, s.durationMs)
            "SWIPE" -> animateSwipe(s.x * screenW, s.y * screenH, s.x2 * screenW, s.y2 * screenH, s.durationMs)
            else -> {}   // WAIT
        }
        val delay = if (el.parallel) 0L else s.durationMs + 30   // parallel: adımlar aynı anda
        h.postDelayed({ runMacro(el, i + 1, token) }, delay)
    }

    private fun tap(x: Float, y: Float, ms: Long) {
        val be = backendProvider() ?: return
        val id = alloc() ?: return
        be.down(id, x, y)
        h.postDelayed({ be.up(id); release(id) }, ms)
    }

    private fun animateSwipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val be = backendProvider() ?: return
        val id = alloc() ?: return
        be.down(id, x1, y1)
        val t0 = SystemClock.uptimeMillis()
        val step = object : Runnable {
            override fun run() {
                val f = ((SystemClock.uptimeMillis() - t0).toFloat() / dur.coerceAtLeast(1)).coerceAtMost(1f)
                be.move(id, x1 + (x2 - x1) * f, y1 + (y2 - y1) * f)
                if (f < 1f) h.postDelayed(this, 16) else { be.up(id); release(id) }
            }
        }
        step.run()
    }

    companion object {
        private const val SPEED = 900f    // gamepad kamera hızı (px/sn)
        private const val DT = 0.016f
    }
}
