package com.example.keymapper.core

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.example.keymapper.IInjector
import com.example.keymapper.service.InjectorService
import rikka.shizuku.Shizuku

/** Shizuku (Wireless Debugging ile başlatılmış) üzerinden shell yetkili enjeksiyon servisi. */
object ShizukuHelper {
    @Volatile var injector: IInjector? = null
    private var binding = false

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName("com.example.keymapper", InjectorService::class.java.name))
            .daemon(false).processNameSuffix("injector").version(1)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            injector = binder?.let { IInjector.Stub.asInterface(it) }
        }
        override fun onServiceDisconnected(name: ComponentName?) { injector = null; binding = false }
    }

    fun isAvailable() = try { Shizuku.pingBinder() } catch (t: Throwable) { false }
    fun hasPermission() = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) { false }

    fun requestPermission() = try { Shizuku.requestPermission(100) } catch (_: Throwable) {}

    fun bind() {
        if (binding || injector != null || !isAvailable() || !hasPermission()) return
        binding = true
        try { Shizuku.bindUserService(args, conn) } catch (t: Throwable) { binding = false }
    }
}
