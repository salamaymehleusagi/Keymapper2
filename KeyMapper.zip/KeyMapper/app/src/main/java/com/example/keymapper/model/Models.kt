package com.example.keymapper.model

import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Ekran üstündeki eşleme elemanı türleri. */
enum class ElementType { BUTTON, JOYSTICK, CAMERA, MACRO, SWIPE, LOCK_TOGGLE }

/** Sanal joystick'i süren fiziksel kaynak. */
enum class StickSource(val label: String) {
    WASD("WASD"),
    ARROWS("Yön tuşları / D-Pad"),
    LEFT_STICK("Sol analog"),
    RIGHT_STICK("Sağ analog")
}

/** Makro adımı. Koordinatlar 0..1 arası normalize (çözünürlükten bağımsız). */
data class MacroStep(
    val kind: String = "TAP",          // TAP | SWIPE | WAIT
    val x: Float = 0f, val y: Float = 0f,
    val x2: Float = 0f, val y2: Float = 0f,
    val durationMs: Long = 60
) {
    fun toJson(): JSONObject = JSONObject()
        .put("kind", kind).put("x", x.toDouble()).put("y", y.toDouble())
        .put("x2", x2.toDouble()).put("y2", y2.toDouble()).put("ms", durationMs)

    companion object {
        fun fromJson(o: JSONObject) = MacroStep(
            o.optString("kind", "TAP"),
            o.optDouble("x", 0.0).toFloat(), o.optDouble("y", 0.0).toFloat(),
            o.optDouble("x2", 0.0).toFloat(), o.optDouble("y2", 0.0).toFloat(),
            o.optLong("ms", 60)
        )
    }
}

/**
 * Tek bir eşleme elemanı.
 *  - x,y,size: normalize (size = yarıçap, ekranın kısa kenarına oranı)
 *  - binding : "K:<keyCode>" | "M:L" | "M:R" | "M:M"
 *      BUTTON/MACRO/SWIPE  -> tetikleyen tuş
 *      LOCK_TOGGLE         -> Aimlock/Shiftlock aç-kapa tuşu
 *      CAMERA              -> ADS (nişan) tuşu: basılıyken adsSens çarpanı uygulanır
 */
data class MappingElement(
    var id: String = UUID.randomUUID().toString(),
    var type: ElementType = ElementType.BUTTON,
    var x: Float = 0.5f, var y: Float = 0.5f, var size: Float = 0.06f,
    var sensitivity: Float = 1f,
    var adsSens: Float = 0.5f,
    var binding: String = "",
    var stick: StickSource = StickSource.WASD,
    var x2: Float = 0.5f, var y2: Float = 0.5f,       // SWIPE bitiş noktası
    var durationMs: Long = 300,                        // SWIPE süresi
    var parallel: Boolean = false,                     // MACRO: tüm adımlar aynı anda
    var loop: Boolean = false,                         // MACRO: tuş basılıyken tekrarla
    var aim: Boolean = false,                          // BUTTON: fare imlecine doğru nişan (sürükle)
    var smooth: Boolean = true,                        // JOYSTICK: yumuşak başlangıç (sürükleme hissi)
    var hold: Boolean = false,                         // BUTTON: false = Bas-Çek (tap), true = Basılı tut
    var tapMs: Long = 40,                              // Bas-Çek: dokunma süresi (ms)
    var delayMs: Long = 0,                             // tetikleme gecikmesi (ms)
    var turbo: Boolean = false,                        // BUTTON(tap): tuş basılıyken otomatik tekrarla
    var intervalMs: Long = 80,                         // turbo tekrar aralığı (ms)
    var gapMs: Long = 60,                              // MACRO: adımlar arası bekleme (ms)
    var steps: MutableList<MacroStep> = mutableListOf()
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("type", type.name)
        .put("x", x.toDouble()).put("y", y.toDouble()).put("size", size.toDouble())
        .put("sens", sensitivity.toDouble()).put("adsSens", adsSens.toDouble())
        .put("binding", binding).put("stick", stick.name)
        .put("x2", x2.toDouble()).put("y2", y2.toDouble()).put("ms", durationMs)
        .put("parallel", parallel).put("loop", loop)
        .put("aim", aim).put("smooth", smooth).put("hold", hold).put("tapMs", tapMs).put("delayMs", delayMs)
        .put("turbo", turbo).put("intervalMs", intervalMs).put("gapMs", gapMs)
        .put("steps", JSONArray().apply { steps.forEach { put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject): MappingElement {
            val arr = o.optJSONArray("steps") ?: JSONArray()
            return MappingElement(
                id = o.optString("id", UUID.randomUUID().toString()),
                type = ElementType.valueOf(o.getString("type")),
                x = o.optDouble("x", 0.5).toFloat(), y = o.optDouble("y", 0.5).toFloat(),
                size = o.optDouble("size", 0.06).toFloat(),
                sensitivity = o.optDouble("sens", 1.0).toFloat(),
                adsSens = o.optDouble("adsSens", 0.5).toFloat(),
                binding = o.optString("binding", ""),
                stick = runCatching { StickSource.valueOf(o.optString("stick", "WASD")) }
                    .getOrDefault(StickSource.WASD),
                x2 = o.optDouble("x2", 0.5).toFloat(), y2 = o.optDouble("y2", 0.5).toFloat(),
                durationMs = o.optLong("ms", 300),
                parallel = o.optBoolean("parallel", false),
                loop = o.optBoolean("loop", false),
                aim = o.optBoolean("aim", false),
                smooth = o.optBoolean("smooth", true),
                hold = o.optBoolean("hold", false),
                tapMs = o.optLong("tapMs", 40),
                delayMs = o.optLong("delayMs", 0),
                turbo = o.optBoolean("turbo", false),
                intervalMs = o.optLong("intervalMs", 80),
                gapMs = o.optLong("gapMs", 60),
                steps = (0 until arr.length()).map { MacroStep.fromJson(arr.getJSONObject(it)) }
                    .toMutableList()
            )
        }
    }
}

/** Profil = isimli eleman listesi. JSON olarak dışa/içe aktarılır. */
data class Profile(var name: String, var elements: MutableList<MappingElement> = mutableListOf()) {
    fun toJson(): JSONObject = JSONObject()
        .put("version", 1).put("name", name)
        .put("elements", JSONArray().apply { elements.forEach { put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject): Profile {
            val arr = o.optJSONArray("elements") ?: JSONArray()
            return Profile(
                o.getString("name"),
                (0 until arr.length()).map { MappingElement.fromJson(arr.getJSONObject(it)) }
                    .toMutableList()
            )
        }
    }
}

/** Binding metinleri için yardımcılar. */
object Binding {
    /**
     * Klavye düzeninden BAĞIMSIZ tuş kodu: W/A/S/D fiziksel konumları (scan code 17/30/31/32)
     * her düzende (Türkçe F, AZERTY ...) WASD sayılır. Diğer tuşlarda normal keyCode.
     */
    fun codeOf(e: KeyEvent): Int = when (e.scanCode) {
        17 -> KeyEvent.KEYCODE_W
        30 -> KeyEvent.KEYCODE_A
        31 -> KeyEvent.KEYCODE_S
        32 -> KeyEvent.KEYCODE_D
        else -> e.keyCode
    }

    fun key(code: Int) = "K:$code"
    /** Kombinasyon: "K:59+K:29" -> "SHIFT_LEFT+A" */
    fun label(b: String): String =
        if (b.isEmpty()) "?" else b.split("+").filter { it.isNotEmpty() }.joinToString("+") { one(it) }

    private fun one(b: String): String = when {
        b.isEmpty() -> "?"
        b == "M:L" -> "LMB"
        b == "M:R" -> "RMB"
        b == "M:M" -> "MMB"
        b.startsWith("K:") -> KeyEvent.keyCodeToString(b.substring(2).toIntOrNull() ?: 0)
            .removePrefix("KEYCODE_")
        else -> b
    }
}
