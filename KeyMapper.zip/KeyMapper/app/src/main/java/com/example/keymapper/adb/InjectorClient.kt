package com.example.keymapper.adb

import android.content.Context
import com.example.keymapper.core.TouchBackend
import com.example.keymapper.data.Prefs
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/**
 * Shell sürecindeki InjectorMain sunucusuna 127.0.0.1 üzerinden bağlanan istemci.
 * Protokol (big-endian):  [op:1] ...
 *   0 DOWN id:int x:float y:float | 1 MOVE id x y | 2 UP id | 3 RESET | 9 STOP
 * Soket yazımları ayrı bir thread'de yapılır (ana thread'de ağ yasak).
 */
object InjectorClient : TouchBackend {
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var sock: Socket? = null
    @Volatile private var out: DataOutputStream? = null

    val isConnected: Boolean
        get() = sock?.let { it.isConnected && !it.isClosed } == true

    /** Sunucuya bağlanıp el sıkışır. Arka plan thread'inde çağır. */
    @Synchronized
    fun connectBlocking(ctx: Context): Boolean {
        if (isConnected) return true
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress("127.0.0.1", Prefs.port(ctx)), 800)
            val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
            o.writeLong(Prefs.token(ctx)); o.flush()
            s.soTimeout = 1500
            val ack = s.getInputStream().read()
            s.soTimeout = 0
            if (ack != 1) { s.close(); false } else { sock = s; out = o; true }
        } catch (e: Exception) { false }
    }

    private fun closeQuiet() {
        try { sock?.close() } catch (_: Exception) {}
        sock = null; out = null
    }

    private fun send(block: (DataOutputStream) -> Unit) {
        exec.execute {
            val o = out ?: return@execute
            try { block(o); o.flush() } catch (e: Exception) { closeQuiet() }
        }
    }

    override fun down(id: Int, x: Float, y: Float) = send {
        it.writeByte(0); it.writeInt(id); it.writeFloat(x); it.writeFloat(y)
    }

    override fun move(id: Int, x: Float, y: Float) = send {
        it.writeByte(1); it.writeInt(id); it.writeFloat(x); it.writeFloat(y)
    }

    override fun up(id: Int) = send { it.writeByte(2); it.writeInt(id) }

    override fun reset() = send { it.writeByte(3) }

    /** Sunucuyu sonlandırır. */
    fun stopServer() {
        if (!isConnected) return
        send { it.writeByte(9) }
        exec.execute { closeQuiet() }
    }
}
