package com.example.keymapper.adb

import android.content.Context
import android.util.Log
import com.example.keymapper.core.TouchBackend
import com.example.keymapper.data.Prefs
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Shell sürecindeki InjectorMain sunucusuna 127.0.0.1 üzerinden bağlanan KALICI istemci.
 * Protokol (big-endian):
 *   0 DOWN id:int x:float y:float | 1 MOVE id x y | 2 UP id | 3 RESET | 4 PING (cevap: 1 hazır / 2 API yok) | 9 STOP
 * Yazımlar tek thread'de sıralı yapılır (ana thread'de ağ yasak, sıra bozulmaz).
 */
object InjectorClient : TouchBackend {
    private const val TAG = "KeyMapper"
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var sock: Socket? = null
    @Volatile private var out: DataOutputStream? = null

    /** Sunucu enjeksiyon API'sini bulabildi mi? (el sıkışmada bildirilir) */
    @Volatile var injectOk = false; private set

    /** Son bağlantı hatasının AYRINTILI nedeni (başarılıysa boş). */
    @Volatile var lastError = ""; private set

    /** Bağlantı beklenmedik şekilde koparsa çağrılır (herhangi bir thread'den). */
    @Volatile var onLost: (() -> Unit)? = null

    /** Soket açık mı? */
    val isConnected: Boolean
        get() = sock?.let { it.isConnected && !it.isClosed } == true

    /**
     * Enjektör GERÇEKTEN kullanılabilir mi? Soket açık VE sunucu enjeksiyon API'sini bulmuş.
     * (Arka uç seçimi ve durum göstergeleri bunu kullanır.)
     */
    val isActive: Boolean
        get() = isConnected && injectOk

    private fun fail(s: Socket?, msg: String): Boolean {
        try { s?.close() } catch (_: Exception) {}
        lastError = msg
        Log.w(TAG, "Enjektör bağlantısı başarısız: $msg")
        return false
    }

    /**
     * Sunucuya bağlanıp el sıkışır. Soket + OutputStream hazır ve sunucu cevap vermeden true DÖNMEZ.
     * Başarısızsa [lastError] nedeni açıklar. Arka plan thread'inde çağır.
     */
    @Synchronized
    fun connectBlocking(ctx: Context): Boolean {
        if (isConnected) return true
        val port = Prefs.port(ctx)
        var s: Socket? = null
        return try {
            s = Socket()
            s.tcpNoDelay = true
            s.keepAlive = true
            s.connect(InetSocketAddress("127.0.0.1", port), 800)
            val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
            o.writeLong(Prefs.token(ctx)); o.flush()
            s.soTimeout = 1500
            val ack = s.getInputStream().read()          // 1 = hazır, 2 = sunucu açık ama API yok
            s.soTimeout = 0
            when (ack) {
                1, 2 -> {
                    injectOk = ack == 1; sock = s; out = o; lastError = ""
                    Log.i(TAG, "Enjektöre bağlanıldı (port $port, enjeksiyon=${if (injectOk) "HAZIR" else "YOK"})")
                    true
                }
                -1 -> fail(s, "Sunucu bağlantıyı hemen kapattı (token reddedildi ya da sunucu çöktü)")
                else -> fail(s, "Beklenmeyen el sıkışma cevabı: $ack")
            }
        } catch (e: ConnectException) {
            fail(s, "Bağlantı reddedildi: $port portunu dinleyen sunucu yok")
        } catch (e: SocketTimeoutException) {
            fail(s, "Zaman aşımı: sunucu el sıkışmaya cevap vermedi")
        } catch (e: SocketException) {
            val denied = e.message?.contains("EACCES") == true
            fail(s, "SocketException: ${e.message}" + if (denied) " (INTERNET izni / SELinux engeli)" else "")
        } catch (e: SecurityException) {
            fail(s, "SecurityException: ${e.message} (INTERNET izni eksik)")
        } catch (e: Exception) {
            fail(s, "${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun closeQuiet(notify: Boolean) {
        val was = sock != null
        try { sock?.close() } catch (_: Exception) {}
        sock = null; out = null
        if (notify && was) {
            Log.w(TAG, "Enjektör bağlantısı koptu")
            onLost?.invoke()
        }
    }

    private fun send(block: (DataOutputStream) -> Unit) {
        exec.execute {
            val o = out ?: return@execute
            try { block(o); o.flush() } catch (e: Exception) {
                Log.w(TAG, "Enjektöre yazılamadı: ${e.javaClass.simpleName}: ${e.message}")
                closeQuiet(true)
            }
        }
    }

    override fun down(id: Int, x: Float, y: Float) = send {
        it.writeByte(0); it.writeInt(id); it.writeFloat(x); it.writeFloat(y)
    }

    override fun move(id: Int, x: Float, y: Float) = send {
        it.writeByte(1); it.writeInt(id); it.writeFloat(x); it.writeFloat(y)
    }

    override fun up(id: Int) = send { it.writeByte(2); it.writeInt(id) }

    override fun reset() = send { it.writeByte(3) }

    /**
     * Sunucunun gerçekten yaşadığını ve enjeksiyon API'sinin hazır olduğunu doğrular.
     * Arka plan thread'inde çağır. Cevap gelmezse bağlantı kapatılır, [lastError] doldurulur.
     */
    fun ping(): Boolean {
        val o = out
        val s = sock
        if (o == null || s == null) { lastError = "Soket kapalı"; return false }
        return try {
            val r = exec.submit(Callable {
                o.writeByte(4); o.flush()
                s.soTimeout = 1500
                val v = s.getInputStream().read()
                s.soTimeout = 0
                v
            }).get(3, TimeUnit.SECONDS)
            if (r == 1) true
            else { lastError = if (r == 2) "Sunucu enjeksiyon API'sini bulamadı" else "Ping cevabı geçersiz ($r)"; false }
        } catch (e: Exception) {
            lastError = "Ping başarısız: ${e.javaClass.simpleName}: ${e.message}"
            Log.w(TAG, lastError)
            closeQuiet(false); false
        }
    }

    /** Sunucuyu sonlandırır. */
    fun stopServer() {
        if (!isConnected) return
        send { it.writeByte(9) }
        exec.execute { closeQuiet(false) }
    }
}
