package com.example.keymapper.adb

import android.content.Context
import com.example.keymapper.core.TouchBackend
import com.example.keymapper.data.Prefs
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Shell sürecindeki InjectorMain sunucusuna 127.0.0.1 üzerinden bağlanan KALICI istemci.
 * Protokol (big-endian):
 *   0 DOWN id:int x:float y:float | 1 MOVE id x y | 2 UP id | 3 RESET | 4 PING (cevap: 1 hazır / 2 API yok) | 9 STOP
 * Tüm yazımlar tek bir thread'de sıralı yapılır (ana thread'de ağ yasak, sıra bozulmaz).
 * Hatalarda soket kapatılır ve [onLost] çağrılır; çağıran yeniden bağlanabilir.
 */
object InjectorClient : TouchBackend {
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var sock: Socket? = null
    @Volatile private var out: DataOutputStream? = null

    /** Sunucu enjeksiyon API'sini bulabildi mi? (el sıkışmada bildirilir) */
    @Volatile var injectOk = false; private set

    /** Bağlantı beklenmedik şekilde koparsa çağrılır (herhangi bir thread'den). */
    @Volatile var onLost: (() -> Unit)? = null

    val isConnected: Boolean
        get() = sock?.let { it.isConnected && !it.isClosed } == true

    /** Sunucuya bağlanıp el sıkışır. Arka plan thread'inde çağır. */
    @Synchronized
    fun connectBlocking(ctx: Context): Boolean {
        if (isConnected) return true
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.keepAlive = true
            s.connect(InetSocketAddress("127.0.0.1", Prefs.port(ctx)), 800)
            val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
            o.writeLong(Prefs.token(ctx)); o.flush()
            s.soTimeout = 1500
            val ack = s.getInputStream().read()          // 1 = hazır, 2 = sunucu açık ama API yok
            s.soTimeout = 0
            if (ack != 1 && ack != 2) { s.close(); false }
            else { injectOk = ack == 1; sock = s; out = o; true }
        } catch (e: Exception) { false }
    }

    private fun closeQuiet(notify: Boolean) {
        val was = sock != null
        try { sock?.close() } catch (_: Exception) {}
        sock = null; out = null
        if (notify && was) onLost?.invoke()
    }

    private fun send(block: (DataOutputStream) -> Unit) {
        exec.execute {
            val o = out ?: return@execute
            try { block(o); o.flush() } catch (e: Exception) { closeQuiet(true) }
        }
    }

    override fun down(id: Int, x: Float, y: Float) = send {
        it.writeByte(0); it.writeInt(id); it.writeFloat(x); it.writeFloat(y)
    }

    override fun move(id: Int, x: Float, y: Float) = send {
        it.writeByte(1); it.writeInt(id); it.writeFloat(x); it.writeFloat(y)
    }

    override fun up(id: Int) = send { it.writeByte(2); it.writeInt(id) }

    override fun reset() = send { it.writeByte(3) }

    /**
     * Sunucunun gerçekten yaşadığını ve enjeksiyon API'sinin hazır olduğunu doğrular.
     * Arka plan thread'inde çağır. Cevap gelmezse bağlantı kapatılır.
     */
    fun ping(): Boolean {
        val o = out ?: return false
        val s = sock ?: return false
        return try {
            exec.submit(Callable {
                o.writeByte(4); o.flush()
                s.soTimeout = 1500
                val r = s.getInputStream().read()
                s.soTimeout = 0
                r == 1
            }).get(3, TimeUnit.SECONDS)
        } catch (e: Exception) { closeQuiet(false); false }
    }

    /** Sunucuyu sonlandırır. */
    fun stopServer() {
        if (!isConnected) return
        send { it.writeByte(9) }
        exec.execute { closeQuiet(false) }
    }
}
