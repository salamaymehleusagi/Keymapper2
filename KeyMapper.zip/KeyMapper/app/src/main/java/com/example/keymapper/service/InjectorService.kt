package com.example.keymapper.service

import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import com.example.keymapper.IInjector
import java.lang.reflect.Method

/**
 * Shizuku tarafından SHELL (uid 2000) sürecinde çalıştırılır.
 * InputManager.injectInputEvent gizli API'sini yansıma (reflection) ile çağırır.
 */
class InjectorService : IInjector.Stub() {
    private var target: Any? = null
    private var method: Method? = null

    init {
        // Android 14+ : InputManagerGlobal, öncesi: InputManager
        for (cn in listOf("android.hardware.input.InputManagerGlobal", "android.hardware.input.InputManager")) {
            try {
                val c = Class.forName(cn)
                target = c.getMethod("getInstance").invoke(null)
                method = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
                if (target != null && method != null) break
            } catch (_: Throwable) { target = null; method = null }
        }
    }

    override fun inject(event: MotionEvent): Boolean {
        event.source = InputDevice.SOURCE_TOUCHSCREEN
        // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
        return try { method?.invoke(target, event, 0) as? Boolean ?: false } catch (_: Throwable) { false }
    }

    override fun destroy() { System.exit(0) }
}
