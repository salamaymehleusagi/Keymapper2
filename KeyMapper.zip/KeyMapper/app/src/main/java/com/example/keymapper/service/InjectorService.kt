package com.example.keymapper.service

import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import com.example.keymapper.IInjector
import java.lang.reflect.Method

/**
 * Shizuku tarafından SHELL (uid 2000) sürecinde çalıştırılır.
 * InputManager.injectInputEvent gizli API'sini yansıma (reflection) ile çağırır.
 */
class InjectorService : IInjector.Stub() {
    private var target: Any? = null
    private var method: Method? = null

    init {
        // Android 14+ : InputManagerGlobal, öncesi: InputManager
        for (cn in listOf("android.hardware.input.InputManagerGlobal", "android.hardware.input.InputManager")) {
            try {
                val c = Class.forName(cn)
                target = c.getMethod("getInstance").invoke(null)
                method = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
                if (target != null && method != null) break
            } catch (_: Throwable) { target = null; method = null }
        }
    }

    override fun inject(action: Int, downTime: Long, ids: IntArray, xs: FloatArray, ys: FloatArray): Boolean {
        val n = ids.size
        if (n == 0) return false
        val props = Array(n) { i ->
            MotionEvent.PointerProperties().apply { id = ids[i]; toolType = MotionEvent.TOOL_TYPE_FINGER }
        }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().apply { x = xs[i]; y = ys[i]; pressure = 1f; size = 1f }
        }
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        return try {
            // 0 = INJECT_INPUT_EVENT_MODE_ASYNC
            method?.invoke(target, ev, 0) as? Boolean ?: false
        } catch (_: Throwable) { false } finally { ev.recycle() }
    }

    override fun destroy() { System.exit(0) }
}
