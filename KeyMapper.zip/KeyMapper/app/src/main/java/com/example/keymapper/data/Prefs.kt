package com.example.keymapper.data

import android.content.Context

/** Basit ayar deposu. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("km", Context.MODE_PRIVATE)

    /** "ACCESSIBILITY" veya "SHIZUKU" */
    fun backend(c: Context): String = sp(c).getString("backend", "ACCESSIBILITY")!!
    fun setBackend(c: Context, v: String) = sp(c).edit().putString("backend", v).apply()

    fun activeProfile(c: Context): String = sp(c).getString("active", "Default")!!
    fun setActiveProfile(c: Context, v: String) = sp(c).edit().putString("active", v).apply()

    /** Oyuna (paket adına) göre otomatik profil yükleme. */
    fun pkgProfile(c: Context, pkg: String): String? = sp(c).getString("pkg_$pkg", null)
    fun setPkgProfile(c: Context, pkg: String, name: String) =
        sp(c).edit().putString("pkg_$pkg", name).apply()
}
