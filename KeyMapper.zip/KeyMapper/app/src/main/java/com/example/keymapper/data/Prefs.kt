package com.example.keymapper.data

import android.content.Context
import java.security.SecureRandom

/** Basit ayar deposu. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("km", Context.MODE_PRIVATE)

    /** "ADB" (yerleşik kablosuz ADB enjektörü) veya "ACCESSIBILITY" */
    fun backend(c: Context): String = sp(c).getString("backend", "ADB")!!
    fun setBackend(c: Context, v: String) = sp(c).edit().putString("backend", v).apply()

    fun activeProfile(c: Context): String = sp(c).getString("active", "Default")!!
    fun setActiveProfile(c: Context, v: String) = sp(c).edit().putString("active", v).apply()

    fun pkgProfile(c: Context, pkg: String): String? = sp(c).getString("pkg_$pkg", null)
    fun setPkgProfile(c: Context, pkg: String, name: String) =
        sp(c).edit().putString("pkg_$pkg", name).apply()

    /** Enjektör sunucusunun yerel TCP portu. */
    fun port(c: Context): Int = sp(c).getInt("inj_port", 38999)

    /** Enjektöre başka uygulamaların bağlanmasını engelleyen gizli anahtar (ilk kullanımda üretilir). */
    @Synchronized
    fun token(c: Context): Long {
        val s = sp(c)
        if (!s.contains("inj_token")) s.edit().putLong("inj_token", SecureRandom().nextLong()).apply()
        return s.getLong("inj_token", 0L)
    }

    fun lastHost(c: Context): String = sp(c).getString("host", "127.0.0.1")!!
    fun setLastHost(c: Context, v: String) = sp(c).edit().putString("host", v).apply()
}
