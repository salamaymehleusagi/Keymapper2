package com.example.keymapper.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * Sanal fare imleci. Gerçek fare yakalandığı (Pointer Capture) için sistem imleci gizlenir;
 * bu tam ekran, dokunulamaz overlay imleci biz çizeriz. Böylece hem kontrol hem imleç görünür.
 */
class CursorView(ctx: Context) : View(ctx) {
    private var cx = 0f
    private var cy = 0f
    private var vis = false
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 2f * d; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    fun update(x: Float, y: Float, visible: Boolean) {
        cx = x; cy = y; vis = visible
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        if (!vis) return
        val s = d
        path.reset()
        path.moveTo(cx, cy)
        path.lineTo(cx, cy + 20f * s)
        path.lineTo(cx + 5.5f * s, cy + 15.5f * s)
        path.lineTo(cx + 10f * s, cy + 24f * s)
        path.lineTo(cx + 13f * s, cy + 22.5f * s)
        path.lineTo(cx + 8.5f * s, cy + 14f * s)
        path.lineTo(cx + 15f * s, cy + 13.5f * s)
        path.close()
        c.drawPath(path, fill)
        c.drawPath(path, edge)
    }
}
