package com.example.keymapper.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.example.keymapper.core.A11yTouchBackend

/**
 * 1) dispatchGesture ile dokunuş enjeksiyonu (A11yTouchBackend)
 * 2) Klavye/gamepad tuşlarını yakalama (onKeyEvent, odak gerekmez)
 * 3) Ön plandaki uygulamayı algılama (oyuna göre otomatik profil)
 */
class KeyMapperAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: KeyMapperAccessibilityService? = null
        /** true dönerse tuş tüketilir (oyuna ulaşmaz). */
        var onKey: ((KeyEvent) -> Boolean)? = null
        var onForegroundPackage: ((String) -> Unit)? = null
    }

    var backend: A11yTouchBackend? = null
        private set

    override fun onServiceConnected() {
        backend = A11yTouchBackend(this)
        instance = this
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            e.packageName?.toString()?.let { onForegroundPackage?.invoke(it) }
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean = onKey?.invoke(event) ?: false

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null; backend = null
        return super.onUnbind(intent)
    }
}
