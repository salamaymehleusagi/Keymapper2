package com.example.keymapper.adb

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import sun.security.x509.AlgorithmId
import sun.security.x509.CertificateAlgorithmId
import sun.security.x509.CertificateExtensions
import sun.security.x509.CertificateIssuerName
import sun.security.x509.CertificateSerialNumber
import sun.security.x509.CertificateSubjectName
import sun.security.x509.CertificateValidity
import sun.security.x509.CertificateVersion
import sun.security.x509.CertificateX509Key
import sun.security.x509.KeyIdentifier
import sun.security.x509.PrivateKeyUsageExtension
import sun.security.x509.SubjectKeyIdentifierExtension
import sun.security.x509.X500Name
import sun.security.x509.X509CertImpl
import sun.security.x509.X509CertInfo
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.Random

/**
 * libadb-android üzerine ADB bağlantı yöneticisi.
 * RSA anahtarı + sertifika dosyada saklanır: eşleme (adb pair) bir kez yapılır ve kalıcı olur.
 */
class KeyMapperAdb private constructor(ctx: Context) : AbsAdbConnectionManager() {

    private lateinit var pKey: PrivateKey
    private lateinit var pCert: Certificate

    init {
        setApi(Build.VERSION.SDK_INT)
        val keyFile = File(ctx.filesDir, "adb_key.pk8")
        val certFile = File(ctx.filesDir, "adb_cert.der")
        var pk: PrivateKey? = null
        var cert: Certificate? = null
        if (keyFile.exists() && certFile.exists()) {
            try {
                pk = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyFile.readBytes()))
                cert = certFile.inputStream().use { CertificateFactory.getInstance("X.509").generateCertificate(it) }
            } catch (_: Exception) { pk = null; cert = null }
        }
        if (pk == null || cert == null) {
            val kpg = KeyPairGenerator.getInstance("RSA")
            kpg.initialize(2048)
            val pair = kpg.generateKeyPair()
            val publicKey = pair.public
            pk = pair.private

            val algo = "SHA512withRSA"
            val notBefore = Date()
            val notAfter = Date(System.currentTimeMillis() + 10L * 365 * 24 * 3600 * 1000)
            val ext = CertificateExtensions()
            ext.set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(publicKey).identifier))
            val name = X500Name("CN=KeyMapper")
            ext.set("PrivateKeyUsage", PrivateKeyUsageExtension(notBefore, notAfter))
            val info = X509CertInfo()
            info.set("version", CertificateVersion(2))
            info.set("serialNumber", CertificateSerialNumber(Random().nextInt() and Int.MAX_VALUE))
            info.set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(algo)))
            info.set("subject", CertificateSubjectName(name))
            info.set("key", CertificateX509Key(publicKey))
            info.set("validity", CertificateValidity(notBefore, notAfter))
            info.set("issuer", CertificateIssuerName(name))
            info.set("extensions", ext)
            val impl = X509CertImpl(info)
            impl.sign(pk, algo)
            cert = impl

            keyFile.writeBytes(pk!!.encoded)
            certFile.writeBytes(cert.encoded)
        }
        pKey = pk!!
        pCert = cert!!
    }

    override fun getPrivateKey(): PrivateKey = pKey
    override fun getCertificate(): Certificate = pCert
    override fun getDeviceName(): String = "KeyMapper"

    companion object {
        @Volatile private var inst: KeyMapperAdb? = null
        fun get(ctx: Context): KeyMapperAdb =
            inst ?: synchronized(this) {
                inst ?: KeyMapperAdb(ctx.applicationContext).also { inst = it }
            }
    }
}
