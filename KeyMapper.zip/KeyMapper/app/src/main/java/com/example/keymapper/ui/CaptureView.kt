package com.example.keymapper.ui

import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import com.example.keymapper.core.InputEngine

/**
 * 1x1 px, dokunulamaz (FLAG_NOT_TOUCHABLE) ama odaklanabilir overlay penceresi.
 * Odağı alarak şunları yakalar:
 *   - fiziksel klavye / gamepad tuşları (dispatchKeyEvent)
 *   - gamepad analog eksenleri (onGenericMotionEvent)
 *   - göreli fare hareketi + fare tuşları (Pointer Capture)
 * Dokunuşlar pencereden geçtiği için oyun ekranı normal çalışmaya devam eder.
 */
class CaptureView(ctx: Context, private val engine: InputEngine) : View(ctx) {

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean =
        engine.onKey(e) || super.dispatchKeyEvent(e)

    override fun onGenericMotionEvent(e: MotionEvent): Boolean =
        engine.onGenericMotion(e) || super.onGenericMotionEvent(e)

    override fun onCapturedPointerEvent(e: MotionEvent): Boolean = engine.onCapturedMouse(e)
}
