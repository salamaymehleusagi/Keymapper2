package com.example.keymapper.ui

import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import com.example.keymapper.core.InputEngine

/**
 * 1x1 px, dokunulamaz (FLAG_NOT_TOUCHABLE) ama odaklanabilir overlay penceresi.
 * Odağı alarak klavye/gamepad tuşlarını, gamepad eksenlerini ve göreli fare hareketini
 * (Pointer Capture) yakalar. Dokunuşlar pencereden geçer, oyun normal çalışmaya devam eder.
 */
class CaptureView(ctx: Context, private val engine: InputEngine) : View(ctx) {

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean =
        engine.onKey(e) || super.dispatchKeyEvent(e)

    override fun onGenericMotionEvent(e: MotionEvent): Boolean =
        engine.onGenericMotion(e) || super.onGenericMotionEvent(e)

    override fun onCapturedPointerEvent(e: MotionEvent): Boolean = engine.onCapturedMouse(e)

    /** Pointer Capture durumu değişince bildirir (true = fare yakalandı). */
    var onCaptureState: ((Boolean) -> Unit)? = null
    private var lastReported: Boolean? = null

    /**
     * Fare yakalama bekçisi: odak gelmeden requestPointerCapture sessizce başarısız olabilir;
     * bu yüzden kilitliyken her 500 ms'de yakalama yoksa yeniden istenir ve durum bildirilir.
     */
    private val keepCapture = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            if (engine.wantsCapture() && hasWindowFocus() && !hasPointerCapture()) requestPointerCapture()
            val has = hasPointerCapture()
            if (lastReported != has) { lastReported = has; onCaptureState?.invoke(has) }
            postDelayed(this, 500)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postDelayed(keepCapture, 300)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(keepCapture)
        super.onDetachedFromWindow()
    }

    /** Odak kaybını bildirir (FloatingService pencereyi yeniden ekleyip odağı geri alır). */
    var onFocusLost: (() -> Unit)? = null

    /**
     * Odak anlık kaybolabilir (ör. enjekte edilen kamera dokunuşu oyun penceresini öne alırsa).
     * Basılı tuşlar HEMEN silinmez: motor kısa bir tolerans süresi tanır, odak geri gelirse
     * hiçbir şey kaybolmaz. Geri gelmezse (FOCUS_GRACE) takılı kalmasın diye bırakılır.
     */
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            engine.onFocusGained()
            if (engine.wantsCapture()) requestPointerCapture()
        } else {
            engine.onFocusLost()
            onFocusLost?.invoke()
        }
    }
}
