package com.example.keymapper.ui

import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import com.example.keymapper.core.InputEngine

/**
 * 1x1 px, dokunulamaz (FLAG_NOT_TOUCHABLE) ama odaklanabilir overlay penceresi.
 * Odağı alarak klavye/gamepad tuşlarını, gamepad eksenlerini ve göreli fare hareketini
 * (Pointer Capture) yakalar. Dokunuşlar pencereden geçer, oyun normal çalışmaya devam eder.
 */
class CaptureView(ctx: Context, private val engine: InputEngine) : View(ctx) {

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean =
        engine.onKey(e) || super.dispatchKeyEvent(e)

    override fun onGenericMotionEvent(e: MotionEvent): Boolean =
        engine.onGenericMotion(e) || super.onGenericMotionEvent(e)

    override fun onCapturedPointerEvent(e: MotionEvent): Boolean = engine.onCapturedMouse(e)

    /** Odak kaybında bırakılan tuşların 'UP' olayı gelmeyebilir: her şeyi bırak, takılma olmasın. */
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (!hasWindowFocus) engine.releaseInputs()
        else if (engine.locked) requestPointerCapture()
    }
}
