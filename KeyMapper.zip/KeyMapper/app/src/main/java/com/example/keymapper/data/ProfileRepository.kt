package com.example.keymapper.data

import android.content.Context
import com.example.keymapper.model.Profile
import org.json.JSONObject
import java.io.File

/** Profilleri filesDir/profiles altında JSON dosyası olarak saklar. */
class ProfileRepository(ctx: Context) {
    private val dir = File(ctx.filesDir, "profiles").apply { mkdirs() }

    private fun file(name: String) =
        File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".json")

    fun list(): List<String> = dir.listFiles()?.mapNotNull {
        runCatching { JSONObject(it.readText()).getString("name") }.getOrNull()
    }?.sorted() ?: emptyList()

    fun save(p: Profile) = file(p.name).writeText(p.toJson().toString(2))

    fun load(name: String): Profile? = file(name).takeIf { it.exists() }?.let {
        runCatching { Profile.fromJson(JSONObject(it.readText())) }.getOrNull()
    }

    fun delete(name: String) { file(name).delete() }

    fun exportJson(p: Profile): String = p.toJson().toString(2)

    /** JSON metnini profil olarak içe aktarır ve kaydeder. */
    fun importJson(text: String): Profile =
        Profile.fromJson(JSONObject(text)).also { save(it) }
}
