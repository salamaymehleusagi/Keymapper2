package com.example.keymapper.core

/** Ekrana çoklu dokunuş enjekte eden arka uç. Koordinatlar piksel cinsindendir. */
interface TouchBackend {
    fun down(id: Int, x: Float, y: Float)
    fun move(id: Int, x: Float, y: Float)
    fun up(id: Int)
}
