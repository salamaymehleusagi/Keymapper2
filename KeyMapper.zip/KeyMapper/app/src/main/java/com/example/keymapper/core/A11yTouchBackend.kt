package com.example.keymapper.core

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path

/**
 * Erişilebilirlik API'si ile çoklu dokunuş.
 *
 * dispatchGesture aynı anda tek jest kabul ettiği için her parmak "continueStroke"
 * zinciriyle kısa (STEP ms) parçalar halinde sürekli yeniden gönderilir.
 * Bir parmak bırakıldığında son parçada willContinue=false verilir.
 */
class A11yTouchBackend(private val svc: AccessibilityService) : TouchBackend {

    private class P(var x: Float, var y: Float) {
        var lx = x; var ly = y          // önceki parçanın bitiş noktası
        var ex = x; var ey = y          // bu parçanın bitiş noktası
        var stroke: GestureDescription.StrokeDescription? = null
        var up = false
    }

    private val ptrs = LinkedHashMap<Int, P>()
    private var inFlight = false

    override fun down(id: Int, x: Float, y: Float) { ptrs[id] = P(x, y); pump() }
    override fun move(id: Int, x: Float, y: Float) { ptrs[id]?.let { it.x = x; it.y = y }; pump() }
    override fun up(id: Int) { ptrs[id]?.up = true; pump() }
    override fun reset() { ptrs.values.forEach { it.up = true }; pump() }

    private fun pump() {
        if (inFlight || ptrs.isEmpty()) return
        val snapshot = LinkedHashMap(ptrs)
        val builder = GestureDescription.Builder()
        var count = 0
        for ((_, p) in snapshot) {
            if (count >= GestureDescription.getMaxStrokeCount()) break
            p.ex = p.x; p.ey = p.y
            val path = Path().apply { moveTo(p.lx, p.ly); lineTo(p.ex, p.ey) }
            val prev = p.stroke
            val s = if (prev == null)
                GestureDescription.StrokeDescription(path, 0, STEP, !p.up)
            else
                prev.continueStroke(path, 0, STEP, !p.up)
            p.stroke = s
            builder.addStroke(s)
            count++
        }
        inFlight = true
        val ok = svc.dispatchGesture(builder.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) = finish(snapshot, true)
            override fun onCancelled(g: GestureDescription?) = finish(snapshot, false)
        }, null)
        if (!ok) { inFlight = false; ptrs.clear() }
    }

    private fun finish(snapshot: Map<Int, P>, completed: Boolean) {
        inFlight = false
        if (!completed) { ptrs.clear(); return }
        for ((id, p) in snapshot) {
            p.lx = p.ex; p.ly = p.ey
            if (p.up && ptrs[id] === p) ptrs.remove(id)
        }
        pump()   // hâlâ basılı parmak varsa zinciri sürdür
    }

    companion object { private const val STEP = 40L }
}
