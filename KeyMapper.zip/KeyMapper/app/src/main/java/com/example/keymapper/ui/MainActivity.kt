package com.example.keymapper.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.example.keymapper.R
import com.example.keymapper.adb.AdbHelper
import com.example.keymapper.adb.InjectorClient
import com.example.keymapper.adb.PairingNotifier
import com.example.keymapper.core.BackendSelector
import com.example.keymapper.data.Prefs
import com.example.keymapper.data.ProfileRepository
import com.example.keymapper.model.Profile
import com.example.keymapper.service.FloatingService
import com.example.keymapper.service.KeyMapperAccessibilityService

/** Kurulum ekranı: izinler, ADB eşleme/bağlanma, enjektör, backend seçimi, profil yönetimi. */
class MainActivity : Activity() {

    private lateinit var repo: ProfileRepository
    private lateinit var llProfiles: LinearLayout
    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var etHost: EditText
    private var pendingExport: Profile? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        repo = ProfileRepository(this)
        tvStatus = findViewById(R.id.tvStatus)
        tvLog = findViewById(R.id.tvLog)
        llProfiles = findViewById(R.id.llProfiles)
        etHost = findViewById(R.id.etHost)
        etHost.setText(Prefs.lastHost(this))

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // ---- ADB eşleme (adb pair) ----
        findViewById<Button>(R.id.btnPair).setOnClickListener {
            val host = host()
            val port = num(R.id.etPairPort)
            val code = findViewById<EditText>(R.id.etPairCode).text.toString().trim()
            if (port <= 0 || code.length != 6) { log("Eşleme portu ve 6 haneli kodu gir"); return@setOnClickListener }
            bg("Eşleniyor…") { AdbHelper.pair(this, host, port, code); "Eşleme başarılı ✅ Şimdi 'Bağlan'a bas." }
        }
        findViewById<Button>(R.id.btnPairNotif).setOnClickListener {
            Prefs.setLastHost(this, host())
            PairingNotifier.showInput(this)
            log("Bildirim gönderildi. Ayarlar'da 'Eşleme koduyla eşle'yi aç, bildirime 'port kod' yaz.")
        }

        // ---- ADB bağlanma (adb connect) ----
        findViewById<Button>(R.id.btnConnect).setOnClickListener {
            val host = host()
            val port = num(R.id.etConnPort)
            if (port <= 0) { log("Bağlantı portunu gir"); return@setOnClickListener }
            bg("Bağlanılıyor…") { AdbHelper.connect(this, host, port); "ADB bağlandı ✅ Şimdi 'Enjektörü başlat'." }
        }
        findViewById<Button>(R.id.btnAutoConnect).setOnClickListener {
            bg("Otomatik aranıyor (mDNS)…") { AdbHelper.autoConnect(this); "ADB bağlandı ✅ Şimdi 'Enjektörü başlat'." }
        }
        findViewById<Button>(R.id.btnInjector).setOnClickListener {
            bg("Enjektör başlatılıyor…") {
                val (ok, msg) = AdbHelper.startInjector(this)
                if (ok) "$msg (artık yüzen ikonu başlatabilirsin)" else msg
            }
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            bg("Test ediliyor…") {
                when {
                    !InjectorClient.connectBlocking(this) ->
                        "Enjektöre bağlanılamadı ❌ ${InjectorClient.lastError}\n'Enjektörü başlat'a bas (önce ADB bağlı olmalı)."
                    !InjectorClient.injectOk -> "Sunucu açık ama dokunuş enjeksiyonu API'si yok ❌"
                    InjectorClient.ping() -> "Enjektör yanıt veriyor ✅ dokunuş enjeksiyonu hazır."
                    else -> "Enjektör yanıt vermedi ❌ ${InjectorClient.lastError}"
                }
            }
        }

        findViewById<Button>(R.id.btnCopyLog).setOnClickListener {
            val cm = getSystemService(android.content.ClipboardManager::class.java)
            cm.setPrimaryClip(android.content.ClipData.newPlainText("KeyMapper günlük", tvLog.text))
            toast("Günlük kopyalandı")
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) { toast("Önce overlay iznini verin"); return@setOnClickListener }
            startForegroundService(Intent(this, FloatingService::class.java))
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, FloatingService::class.java))
        }
        findViewById<Button>(R.id.btnNewProfile).setOnClickListener { newProfileDialog() }
        findViewById<Button>(R.id.btnImport).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, REQ_IMPORT)
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus(); refreshProfiles()
    }

    // ------------------------------------------------------------------ yardımcılar
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun log(s: String) { tvLog.text = s }
    private fun host(): String = etHost.text.toString().trim().ifEmpty { "127.0.0.1" }
        .also { Prefs.setLastHost(this, it) }
    private fun num(id: Int): Int = findViewById<EditText>(id).text.toString().trim().toIntOrNull() ?: -1

    /** Bloklayıcı işi arka planda çalıştırır; sonucu/hatayı ekrana yazar. */
    private fun bg(startMsg: String, work: () -> String) {
        log(startMsg)
        // Tüm ADB işleri tek kuyrukta seri çalışır (aynı anda iki akış açılmaz)
        AdbHelper.io.execute {
            val res = try { work() } catch (e: Throwable) { "Hata: ${e.message ?: e.javaClass.simpleName}" }
            runOnUiThread { log(res); updateStatus() }
        }
    }

    private fun updateStatus() {
        fun ok(b: Boolean) = if (b) "✅" else "❌"
        tvStatus.text = "${ok(Settings.canDrawOverlays(this))} Overlay izni\n" +
            "${ok(AdbHelper.connected)} ADB bağlı (bu oturum)\n" +
            "${ok(InjectorClient.isActive)} Enjektör aktif (soket + API)\n" +
            "${ok(KeyMapperAccessibilityService.instance != null)} Erişilebilirlik (yedek)\n" +
            "▶ Aktif enjeksiyon: ${BackendSelector.label()}"
    }

    // ------------------------------------------------------------------ profil yönetimi
    private fun refreshProfiles() {
        llProfiles.removeAllViews()
        val active = Prefs.activeProfile(this)
        for (name in repo.list()) {
            llProfiles.addView(TextView(this).apply {
                text = (if (name == active) "● " else "○ ") + name
                textSize = 18f; setPadding(0, 24, 0, 24)
                setOnClickListener { Prefs.setActiveProfile(this@MainActivity, name); refreshProfiles() }
                setOnLongClickListener { profileMenu(name); true }
            })
        }
    }

    private fun profileMenu(name: String) {
        AlertDialog.Builder(this).setTitle(name)
            .setItems(arrayOf("JSON olarak dışa aktar", "Sil")) { _, i ->
                if (i == 0) {
                    pendingExport = repo.load(name)
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "$name.json")
                    }, REQ_EXPORT)
                } else { repo.delete(name); refreshProfiles() }
            }.show()
    }

    private fun newProfileDialog() {
        val et = EditText(this).apply { hint = "Profil adı (ör. PUBG)" }
        AlertDialog.Builder(this).setTitle("Yeni profil").setView(et)
            .setPositiveButton("Oluştur") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    repo.save(Profile(n)); Prefs.setActiveProfile(this, n); refreshProfiles()
                }
            }.setNegativeButton("İptal", null).show()
    }

    @Deprecated("Basit tutmak için klasik API")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        try {
            when (req) {
                REQ_IMPORT -> {
                    val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    val p = repo.importJson(text)
                    toast("İçe aktarıldı: ${p.name}"); refreshProfiles()
                }
                REQ_EXPORT -> pendingExport?.let { p ->
                    contentResolver.openOutputStream(uri)!!.bufferedWriter().use { it.write(repo.exportJson(p)) }
                    toast("Dışa aktarıldı")
                }
            }
        } catch (e: Exception) { toast("Hata: ${e.message}") }
    }

    companion object { private const val REQ_IMPORT = 10; private const val REQ_EXPORT = 11 }
}
