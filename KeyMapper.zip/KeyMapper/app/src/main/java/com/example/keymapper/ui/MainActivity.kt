package com.example.keymapper.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import com.example.keymapper.R
import com.example.keymapper.core.ShizukuHelper
import com.example.keymapper.data.Prefs
import com.example.keymapper.data.ProfileRepository
import com.example.keymapper.model.Profile
import com.example.keymapper.service.FloatingService
import com.example.keymapper.service.KeyMapperAccessibilityService
import rikka.shizuku.Shizuku

/** Kurulum ekranı: izinler, backend seçimi, servis başlat/durdur, profil yönetimi. */
class MainActivity : Activity() {

    private lateinit var repo: ProfileRepository
    private lateinit var llProfiles: LinearLayout
    private lateinit var tvStatus: TextView
    private var pendingExport: Profile? = null

    private val shizukuPermListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) ShizukuHelper.bind()
        runOnUiThread { updateStatus() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        repo = ProfileRepository(this)
        tvStatus = findViewById(R.id.tvStatus)
        llProfiles = findViewById(R.id.llProfiles)

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        runCatching { Shizuku.addRequestPermissionResultListener(shizukuPermListener) }

        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnShizuku).setOnClickListener {
            when {
                !ShizukuHelper.isAvailable() -> toast("Önce Shizuku'yu başlatın (Kablosuz hata ayıklama ile)")
                !ShizukuHelper.hasPermission() -> ShizukuHelper.requestPermission()
                else -> { ShizukuHelper.bind(); toast("Shizuku hazır") }
            }
            updateStatus()
        }

        val rg = findViewById<RadioGroup>(R.id.rgBackend)
        rg.check(if (Prefs.backend(this) == "SHIZUKU") R.id.rbShizuku else R.id.rbA11y)
        rg.setOnCheckedChangeListener { _, id ->
            Prefs.setBackend(this, if (id == R.id.rbShizuku) "SHIZUKU" else "ACCESSIBILITY")
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) { toast("Önce overlay iznini verin"); return@setOnClickListener }
            ShizukuHelper.bind()
            startForegroundService(Intent(this, FloatingService::class.java))
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, FloatingService::class.java))
        }
        findViewById<Button>(R.id.btnNewProfile).setOnClickListener { newProfileDialog() }
        findViewById<Button>(R.id.btnImport).setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, REQ_IMPORT)
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus(); refreshProfiles()
    }

    override fun onDestroy() {
        runCatching { Shizuku.removeRequestPermissionResultListener(shizukuPermListener) }
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun updateStatus() {
        fun ok(b: Boolean) = if (b) "✅" else "❌"
        tvStatus.text = "${ok(Settings.canDrawOverlays(this))} Overlay izni\n" +
            "${ok(KeyMapperAccessibilityService.instance != null)} Erişilebilirlik hizmeti\n" +
            "${ok(ShizukuHelper.isAvailable())} Shizuku çalışıyor   " +
            "${ok(ShizukuHelper.hasPermission())} Shizuku izni   " +
            "${ok(ShizukuHelper.injector != null)} Enjektör bağlı"
    }

    // ------------------------------------------------------------------ profil yönetimi
    private fun refreshProfiles() {
        llProfiles.removeAllViews()
        val active = Prefs.activeProfile(this)
        for (name in repo.list()) {
            llProfiles.addView(TextView(this).apply {
                text = (if (name == active) "● " else "○ ") + name
                textSize = 18f; setPadding(0, 24, 0, 24)
                setOnClickListener { Prefs.setActiveProfile(this@MainActivity, name); refreshProfiles() }
                setOnLongClickListener { profileMenu(name); true }
            })
        }
    }

    private fun profileMenu(name: String) {
        AlertDialog.Builder(this).setTitle(name)
            .setItems(arrayOf("JSON olarak dışa aktar", "Sil")) { _, i ->
                if (i == 0) {
                    pendingExport = repo.load(name)
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                        putExtra(Intent.EXTRA_TITLE, "$name.json")
                    }, REQ_EXPORT)
                } else { repo.delete(name); refreshProfiles() }
            }.show()
    }

    private fun newProfileDialog() {
        val et = EditText(this).apply { hint = "Profil adı (ör. PUBG)" }
        AlertDialog.Builder(this).setTitle("Yeni profil").setView(et)
            .setPositiveButton("Oluştur") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    repo.save(Profile(n)); Prefs.setActiveProfile(this, n); refreshProfiles()
                }
            }.setNegativeButton("İptal", null).show()
    }

    @Deprecated("Basit tutmak için klasik API")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        try {
            when (req) {
                REQ_IMPORT -> {
                    val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                    val p = repo.importJson(text)
                    toast("İçe aktarıldı: ${p.name}"); refreshProfiles()
                }
                REQ_EXPORT -> pendingExport?.let { p ->
                    contentResolver.openOutputStream(uri)!!.bufferedWriter().use { it.write(repo.exportJson(p)) }
                    toast("Dışa aktarıldı")
                }
            }
        } catch (e: Exception) { toast("Hata: ${e.message}") }
    }

    companion object { private const val REQ_IMPORT = 10; private const val REQ_EXPORT = 11 }
}
