package com.example.keymapper.adb

import android.content.Context
import android.os.Build
import android.util.Log
import com.example.keymapper.data.Prefs
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Yerleşik ADB istemcisi: eşleme -> bağlanma -> enjeksiyon sunucusunu başlatma.
 *
 * Tüm ADB işleri TEK bir arka plan kuyruğunda ([io]) seri çalışır; libadb thread-safe değildir.
 * Hiçbir fonksiyon ana thread'de çağrılmamalı. Hatalar istisna olarak yükselir veya rapora yazılır;
 * uygulamayı çökertmez.
 */
object AdbHelper {
    private const val TAG = "KeyMapper"

    /** Tüm bloklayıcı ADB işleri buraya gönderilir. */
    val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val watchdog = Executors.newSingleThreadScheduledExecutor()

    @Volatile var connected = false

    // ---- Sunucuyu taşıyan KALICI interaktif ADB akışı ----
    // Sunucu bu akışın ÖN PLAN komutu olarak çalışır; akış açık kaldığı sürece süreç ölmez
    // (arka plana atılan süreçler adbd tarafından akış kapanınca öldürülebiliyor).
    private val serverOut = StringBuilder()
    @Volatile private var serverAlive = false
    @Volatile private var serverGen = 0
    private var serverCloser: (() -> Unit)? = null

    /** Sunucunun akıştan gelen son çıktısı (hata ayıklama). */
    fun serverOutput(): String = synchronized(serverOut) { serverOut.toString().trim() }

    private fun closeServerStream() {
        try { serverCloser?.invoke() } catch (_: Exception) {}
        serverCloser = null
        serverAlive = false
    }

    /** Komutu açık kalan bir shell akışında çalıştırır; çıktı sürekli arka planda boşaltılır. */
    private fun openServerStream(ctx: Context, cmd: String) {
        closeServerStream()
        synchronized(serverOut) { serverOut.setLength(0) }
        val stream = KeyMapperAdb.get(ctx).openStream("shell:$cmd")
        val input = stream.openInputStream()
        serverCloser = { try { stream.close() } catch (_: Exception) {} }
        val gen = ++serverGen
        serverAlive = true
        Thread({
            val buf = ByteArray(2048)
            try {
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    val text = String(buf, 0, n, Charsets.UTF_8)
                    Log.i(TAG, "sunucu: ${text.trim()}")
                    synchronized(serverOut) {
                        serverOut.append(text)
                        if (serverOut.length > 4000) serverOut.delete(0, serverOut.length - 4000)
                    }
                }
            } catch (_: Exception) {
                // "Stream closed" = süreç bitti / akış kapandı: çökme değil, normal kapanış
            } finally {
                if (gen == serverGen) serverAlive = false
            }
        }, "km-server-stream").apply { isDaemon = true; start() }
    }

    /** adb pair <host>:<port> <kod> */
    fun pair(ctx: Context, host: String, port: Int, code: String) {
        KeyMapperAdb.get(ctx).pair(host, port, code)
    }

    /** adb connect <host>:<port> (host/port kaydedilir: koparsa otomatik yeniden bağlanır) */
    fun connect(ctx: Context, host: String, port: Int) {
        connected = false
        KeyMapperAdb.get(ctx).connect(host, port)
        connected = true
        Prefs.setConn(ctx, host, port)
    }

    /** mDNS ile IP/port'u otomatik bulup bağlanır. */
    fun autoConnect(ctx: Context) {
        connected = false
        KeyMapperAdb.get(ctx).connectTls(ctx, 10000)
        connected = true
    }

    /** Kopan ADB bağlantısını yeniden kurar: önce kayıtlı host:port, olmazsa mDNS. */
    private fun reconnect(ctx: Context) {
        connected = false
        val port = Prefs.connPort(ctx)
        if (port > 0) {
            try { connect(ctx, Prefs.lastHost(ctx), port); return } catch (_: Exception) {}
        }
        autoConnect(ctx)          // başarısızsa istisna fırlatır
    }

    /** Bağlantı canlı mı? Küçük bir komutla sınar; ölüyse yeniden bağlanır. Hatada istisna. */
    fun ensureConnected(ctx: Context) {
        if (connected) {
            try { execShell(ctx, "echo ok", 6); return } catch (_: Exception) { connected = false }
        }
        reconnect(ctx)
    }

    /**
     * Tek seferlik shell komutu. Komut bitince adbd akışı kapatır; kapanmış akıştan okurken
     * kütüphane "Stream closed" fırlatır: bu EOF sayılır. Akış takılırsa bekçi (watchdog)
     * [timeoutSec] sonra akışı kapatır, böylece ADB kuyruğu asla kilitlenmez.
     */
    private fun execShell(ctx: Context, cmd: String, timeoutSec: Long = 10): String {
        val stream = KeyMapperAdb.get(ctx).openStream("shell:$cmd")
        val guard = watchdog.schedule(
            Runnable { try { stream.close() } catch (_: Exception) {} }, timeoutSec, TimeUnit.SECONDS
        )
        val sb = StringBuilder()
        try {
            val input = stream.openInputStream()
            val buf = ByteArray(4096)
            while (true) {
                val n = try { input.read(buf) } catch (e: IOException) { -1 }
                if (n < 0) break
                sb.append(String(buf, 0, n, Charsets.UTF_8))
            }
        } finally {
            guard.cancel(false)
            try { stream.close() } catch (_: Exception) {}
        }
        return sb.toString()
    }

    /** adb shell <cmd>. Bağlantı düşmüşse bir kez yeniden bağlanıp tekrar dener. */
    fun shell(ctx: Context, cmd: String, timeoutSec: Long = 10): String {
        ensureConnected(ctx)
        return try {
            execShell(ctx, cmd, timeoutSec)
        } catch (e: Exception) {
            reconnect(ctx)
            execShell(ctx, cmd, timeoutSec)
        }
    }

    /**
     * Enjeksiyon sunucusunu (yeniden) başlatır ve DOĞRULAR. (başarılı mı, adım adım rapor) döndürür.
     * Sunucu, KALICI interaktif ADB akışında ön plan komutu olarak çalışır; çıktısı canlı okunur.
     * "Aktif" koşulu: soket açık + el sıkışma + sunucu enjeksiyon API'sini buldu + ping cevabı.
     * NOT: Bu akış açık kaldığı sürece sunucu yaşar; ADB bağlantısını / kablosuz hata ayıklamayı kapatma.
     */
    fun startInjector(ctx: Context): Pair<Boolean, String> {
        val rep = StringBuilder()
        fun step(s: String) { rep.appendLine(s); Log.i(TAG, s) }
        fun fail(): Pair<Boolean, String> = Pair(false, rep.toString().trim())
        fun logcatDiag(): String = try {
            shell(ctx, "logcat -d -b all -t 500 2>&1 | grep -iE 'AndroidRuntime|km_injector|InjectorMain|app_process|keymapper' | tail -n 18", 12).trim()
        } catch (e: Exception) { "(logcat okunamadı: ${e.message})" }

        try {
            step("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.SUPPORTED_ABIS.firstOrNull()}")

            // 0) Eski sunucu varsa kapat (güncel kodla yeniden başlasın)
            if (InjectorClient.connectBlocking(ctx)) {
                step("[0] Eski enjektör bulundu, kapatılıyor")
                InjectorClient.stopServer()
                Thread.sleep(600)
            }
            closeServerStream()

            // 1) ADB
            try {
                ensureConnected(ctx)
                step("[1] ADB bağlantısı ✅")
            } catch (e: Exception) {
                step("[1] ADB bağlantısı ❌ ${e.javaClass.simpleName}: ${e.message}")
                step("    → Önce 'Eşle' ve 'Bağlan'/'Otomatik bağlan' adımlarını yap.")
                return fail()
            }

            // 2) Kabuk kullanıcısı
            val id = shell(ctx, "id").trim()
            step("[2] Kabuk: " + (if (id.contains("uid=2000")) "uid=2000(shell) ✅" else "$id ⚠️"))

            // 3) APK kabuk tarafından okunabiliyor mu?
            val apk = ctx.applicationInfo.sourceDir
            val ls = shell(ctx, "ls -l '$apk' 2>&1").trim()
            val apkOk = !ls.contains("No such file") && !ls.contains("denied") && ls.isNotEmpty()
            step("[3] APK ${if (apkOk) "✅" else "❌: $ls"}")
            if (!apkOk) return fail()

            // 4) Sunucuyu KALICI akışta ön planda başlat (exec: shell yerine geçer, & / nohup yok)
            val port = Prefs.port(ctx)
            val token = Prefs.token(ctx)
            val cmd = "export CLASSPATH='$apk'; exec app_process /system/bin --nice-name=km_injector " +
                "com.example.keymapper.shell.InjectorMain $port $token 2>&1"
            openServerStream(ctx, cmd)
            step("[4] Sunucu kalıcı ADB akışında başlatıldı (port $port)")

            // 5) Doğrulama döngüsü (ilk JVM açılışı yavaş olabilir: ~16 sn'ye kadar bekle)
            var tries = 0
            while (tries < 40) {
                tries++
                Thread.sleep(400)
                if (InjectorClient.connectBlocking(ctx)) {
                    val out = serverOutput()
                    if (!InjectorClient.injectOk) {
                        step("[5] Sunucu açık ama dokunuş enjeksiyonu API'si bulunamadı ❌")
                        step("    Sunucu çıktısı: ${out.ifEmpty { "(boş)" }}")
                        return fail()
                    }
                    if (InjectorClient.ping()) {
                        step("[5] Soket + el sıkışma + ping ✅ (deneme $tries)")
                        if (out.isNotEmpty()) step("    Sunucu: ${out.lines().firstOrNull()}")
                        return Pair(true, rep.toString().trim())
                    }
                    step("[5] Bağlandı ama ping başarısız ❌ ${InjectorClient.lastError}")
                    return fail()
                }
                if (!serverAlive && tries >= 2) {
                    step("[5] Sunucu süreci kapandı (başlamadı veya çöktü) ❌")
                    step("    Sunucu çıktısı: ${serverOutput().ifEmpty { "(boş)" }}")
                    step("    Sistem günlüğü:\n${logcatDiag().ifEmpty { "(ilgili satır yok)" }}")
                    return fail()
                }
            }
            step("[5] Zaman aşımı ❌ Son soket hatası: ${InjectorClient.lastError}")
            step("    Akış açık mı: $serverAlive | Sunucu çıktısı: ${serverOutput().ifEmpty { "(boş)" }}")
            step("    Sistem günlüğü:\n${logcatDiag().ifEmpty { "(ilgili satır yok)" }}")
            return fail()
        } catch (e: Exception) {
            Log.e(TAG, "startInjector hatası", e)
            step("HATA: ${e.javaClass.simpleName}: ${e.message}")
            return fail()
        }
    }
}
