package com.example.keymapper.adb

import android.content.Context
import com.example.keymapper.data.Prefs
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Yerleşik ADB istemcisi: eşleme -> bağlanma -> enjeksiyon sunucusunu başlatma.
 *
 * Tüm ADB işlemleri TEK bir arka plan kuyruğunda ([io]) seri çalışır: libadb thread-safe değildir
 * ve aynı anda iki akış açılması "Stream closed" hatalarına yol açar.
 */
object AdbHelper {
    /** Tüm bloklayıcı ADB işleri buraya gönderilir (ana thread'i asla bloklama). */
    val io: ExecutorService = Executors.newSingleThreadExecutor()

    @Volatile var connected = false

    private const val LOG = "/data/local/tmp/km_injector.log"

    /** adb pair <host>:<port> <kod> */
    fun pair(ctx: Context, host: String, port: Int, code: String) {
        KeyMapperAdb.get(ctx).pair(host, port, code)
    }

    /** adb connect <host>:<port>  (host/port kaydedilir: koparsa otomatik yeniden bağlanır) */
    fun connect(ctx: Context, host: String, port: Int) {
        connected = false
        KeyMapperAdb.get(ctx).connect(host, port)
        connected = true
        Prefs.setConn(ctx, host, port)
    }

    /** mDNS ile IP/port'u otomatik bulup bağlanır. */
    fun autoConnect(ctx: Context) {
        connected = false
        KeyMapperAdb.get(ctx).connectTls(ctx, 10000)
        connected = true
    }

    /** Kopan ADB bağlantısını yeniden kurar: önce kayıtlı host:port, olmazsa mDNS. */
    private fun reconnect(ctx: Context) {
        connected = false
        val port = Prefs.connPort(ctx)
        if (port > 0) {
            try { connect(ctx, Prefs.lastHost(ctx), port); return } catch (_: Exception) {}
        }
        autoConnect(ctx)          // başarısızsa istisna fırlatır
    }

    /**
     * Bağlantı canlı mı? Küçük bir komutla sınar; ölüyse yeniden bağlanır.
     * Başarısızsa istisna fırlatır.
     */
    fun ensureConnected(ctx: Context) {
        if (connected) {
            try { execShell(ctx, "echo ok"); return } catch (_: Exception) { connected = false }
        }
        reconnect(ctx)
    }

    /**
     * Tek seferlik bir shell komutu çalıştırır ve çıktısını döndürür.
     * ÖNEMLİ: komut bitince adbd akışı kapatır; kapanmış akıştan okurken kütüphane
     * "Stream closed" fırlatır. Bu hata "komut bitti" anlamına geldiği için EOF sayılır.
     */
    private fun execShell(ctx: Context, cmd: String): String {
        val stream = KeyMapperAdb.get(ctx).openStream("shell:$cmd")
        val sb = StringBuilder()
        try {
            val input = stream.openInputStream()
            val buf = ByteArray(4096)
            while (true) {
                val n = try { input.read(buf) } catch (e: IOException) { -1 }
                if (n < 0) break
                sb.append(String(buf, 0, n, Charsets.UTF_8))
            }
        } finally {
            try { stream.close() } catch (_: Exception) {}
        }
        return sb.toString()
    }

    /** adb shell <cmd>. Bağlantı düşmüşse bir kez yeniden bağlanıp tekrar dener. */
    fun shell(ctx: Context, cmd: String): String {
        ensureConnected(ctx)
        return try {
            execShell(ctx, cmd)
        } catch (e: Exception) {
            reconnect(ctx)
            execShell(ctx, cmd)
        }
    }

    /**
     * shell (uid 2000) yetkisiyle app_process ile enjeksiyon sunucusunu (yeniden) başlatır,
     * soketle bağlanır ve ping ile doğrular. (başarılı mı, mesaj) döndürür.
     * Hatada sunucunun günlüğünü de mesaja ekler.
     */
    fun startInjector(ctx: Context): Pair<Boolean, String> {
        return try {
            // Eski sunucu varsa kapat (güncel kodla yeniden başlasın)
            if (InjectorClient.connectBlocking(ctx)) {
                InjectorClient.stopServer()
                Thread.sleep(500)
            }
            ensureConnected(ctx)
            val apk = ctx.applicationInfo.sourceDir
            val port = Prefs.port(ctx)
            val token = Prefs.token(ctx)
            // setsid varsa kullan (adb akışı kapanınca sürecin öldürülmesini engeller)
            val cmd = "rm -f $LOG; export CLASSPATH='$apk'; S=''; " +
                "command -v setsid >/dev/null 2>&1 && S=setsid; " +
                "\$S nohup app_process /system/bin --nice-name=km_injector " +
                "com.example.keymapper.shell.InjectorMain $port $token >$LOG 2>&1 </dev/null &"
            shell(ctx, cmd)

            repeat(25) {
                Thread.sleep(300)
                if (InjectorClient.connectBlocking(ctx)) {
                    return if (InjectorClient.injectOk && InjectorClient.ping())
                        Pair(true, "Enjektör çalışıyor ✅")
                    else
                        Pair(false, "Sunucu açık ama dokunuş enjeksiyonu API'si bulunamadı (Android sürümü desteklenmiyor olabilir).")
                }
            }
            val diag = try { shell(ctx, "cat $LOG; ps -A | grep km_injector") } catch (_: Exception) { "" }
            Pair(false, "Enjektör başlamadı. ${diag.trim().take(300)}")
        } catch (e: Exception) {
            Pair(false, "ADB hatası: ${e.message ?: e.javaClass.simpleName}. Önce eşle ve bağlan.")
        }
    }
}
