package com.example.keymapper.adb

import android.content.Context
import com.example.keymapper.data.Prefs

/**
 * Yerleşik ADB istemcisi üzerinden: eşleme -> bağlanma -> enjeksiyon sunucusunu başlatma.
 * Tüm fonksiyonlar bloklayıcıdır; ARKA PLAN thread'inde çağır.
 */
object AdbHelper {
    @Volatile var connected = false

    /** adb pair <host>:<port> <kod>  (6 haneli kod) */
    fun pair(ctx: Context, host: String, port: Int, code: String) {
        KeyMapperAdb.get(ctx).pair(host, port, code)
    }

    /** adb connect <host>:<port> */
    fun connect(ctx: Context, host: String, port: Int) {
        connected = false
        KeyMapperAdb.get(ctx).connect(host, port)
        connected = true
    }

    /** mDNS ile IP/port'u otomatik bulup bağlanır. */
    fun autoConnect(ctx: Context) {
        connected = false
        KeyMapperAdb.get(ctx).connectTls(ctx, 10000)
        connected = true
    }

    /** adb shell <cmd> çalıştırır, çıktıyı döndürür. */
    fun shell(ctx: Context, cmd: String): String {
        val stream = KeyMapperAdb.get(ctx).openStream("shell:$cmd")
        try {
            return stream.openInputStream().readBytes().toString(Charsets.UTF_8)
        } finally {
            try { stream.close() } catch (_: Exception) {}
        }
    }

    /**
     * shell (uid 2000) yetkisiyle app_process ile enjeksiyon sunucusunu başlatır
     * ve ona soketle bağlanır. Başarılıysa true.
     */
    fun startInjector(ctx: Context): Boolean {
        InjectorClient.stopServer()                       // eski sürüm çalışıyorsa kapat
        Thread.sleep(300)
        val apk = ctx.applicationInfo.sourceDir
        val port = Prefs.port(ctx)
        val token = Prefs.token(ctx)
        val cmd = "CLASSPATH='$apk' setsid nohup app_process /system/bin " +
            "--nice-name=km_injector com.example.keymapper.shell.InjectorMain $port $token " +
            ">/dev/null 2>&1 </dev/null &"
        shell(ctx, cmd)
        repeat(20) {
            Thread.sleep(300)
            if (InjectorClient.connectBlocking(ctx)) return true
        }
        return false
    }
}
