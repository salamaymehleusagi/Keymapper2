package com.example.keymapper.adb

import android.content.Context
import android.os.Build
import android.util.Log
import com.example.keymapper.data.Prefs
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Yerleşik ADB istemcisi: eşleme -> bağlanma -> enjeksiyon sunucusunu başlatma.
 *
 * Tüm ADB işleri TEK bir arka plan kuyruğunda ([io]) seri çalışır; libadb thread-safe değildir.
 * Hiçbir fonksiyon ana thread'de çağrılmamalı. Hatalar istisna olarak yükselir veya rapora yazılır;
 * uygulamayı çökertmez.
 */
object AdbHelper {
    private const val TAG = "KeyMapper"
    private const val LOG = "/data/local/tmp/km_injector.log"

    /** Tüm bloklayıcı ADB işleri buraya gönderilir. */
    val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val watchdog = Executors.newSingleThreadScheduledExecutor()

    @Volatile var connected = false

    /** adb pair <host>:<port> <kod> */
    fun pair(ctx: Context, host: String, port: Int, code: String) {
        KeyMapperAdb.get(ctx).pair(host, port, code)
    }

    /** adb connect <host>:<port> (host/port kaydedilir: koparsa otomatik yeniden bağlanır) */
    fun connect(ctx: Context, host: String, port: Int) {
        connected = false
        KeyMapperAdb.get(ctx).connect(host, port)
        connected = true
        Prefs.setConn(ctx, host, port)
    }

    /** mDNS ile IP/port'u otomatik bulup bağlanır. */
    fun autoConnect(ctx: Context) {
        connected = false
        KeyMapperAdb.get(ctx).connectTls(ctx, 10000)
        connected = true
    }

    /** Kopan ADB bağlantısını yeniden kurar: önce kayıtlı host:port, olmazsa mDNS. */
    private fun reconnect(ctx: Context) {
        connected = false
        val port = Prefs.connPort(ctx)
        if (port > 0) {
            try { connect(ctx, Prefs.lastHost(ctx), port); return } catch (_: Exception) {}
        }
        autoConnect(ctx)          // başarısızsa istisna fırlatır
    }

    /** Bağlantı canlı mı? Küçük bir komutla sınar; ölüyse yeniden bağlanır. Hatada istisna. */
    fun ensureConnected(ctx: Context) {
        if (connected) {
            try { execShell(ctx, "echo ok", 6); return } catch (_: Exception) { connected = false }
        }
        reconnect(ctx)
    }

    /**
     * Tek seferlik shell komutu. Komut bitince adbd akışı kapatır; kapanmış akıştan okurken
     * kütüphane "Stream closed" fırlatır: bu EOF sayılır. Akış takılırsa bekçi (watchdog)
     * [timeoutSec] sonra akışı kapatır, böylece ADB kuyruğu asla kilitlenmez.
     */
    private fun execShell(ctx: Context, cmd: String, timeoutSec: Long = 10): String {
        val stream = KeyMapperAdb.get(ctx).openStream("shell:$cmd")
        val guard = watchdog.schedule(
            Runnable { try { stream.close() } catch (_: Exception) {} }, timeoutSec, TimeUnit.SECONDS
        )
        val sb = StringBuilder()
        try {
            val input = stream.openInputStream()
            val buf = ByteArray(4096)
            while (true) {
                val n = try { input.read(buf) } catch (e: IOException) { -1 }
                if (n < 0) break
                sb.append(String(buf, 0, n, Charsets.UTF_8))
            }
        } finally {
            guard.cancel(false)
            try { stream.close() } catch (_: Exception) {}
        }
        return sb.toString()
    }

    /** adb shell <cmd>. Bağlantı düşmüşse bir kez yeniden bağlanıp tekrar dener. */
    fun shell(ctx: Context, cmd: String, timeoutSec: Long = 10): String {
        ensureConnected(ctx)
        return try {
            execShell(ctx, cmd, timeoutSec)
        } catch (e: Exception) {
            reconnect(ctx)
            execShell(ctx, cmd, timeoutSec)
        }
    }

    /**
     * Enjeksiyon sunucusunu (yeniden) başlatır ve DOĞRULAR. (başarılı mı, adım adım rapor) döndürür.
     * Rapor her adımın sonucunu ve hatanın kesin nedenini içerir; logcat'e de (etiket: KeyMapper) yazılır.
     *
     * "Aktif" sayılma koşulu: soket açıldı + el sıkışma tamam + sunucu enjeksiyon API'sini buldu + ping cevabı.
     */
    fun startInjector(ctx: Context): Pair<Boolean, String> {
        val rep = StringBuilder()
        fun step(s: String) { rep.appendLine(s); Log.i(TAG, s) }
        fun fail(): Pair<Boolean, String> = Pair(false, rep.toString().trim())

        try {
            step("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.SUPPORTED_ABIS.firstOrNull()}")

            // 0) Eski sunucu varsa kapat (güncel kodla yeniden başlasın)
            if (InjectorClient.connectBlocking(ctx)) {
                step("[0] Eski enjektör bulundu, kapatılıyor")
                InjectorClient.stopServer()
                Thread.sleep(600)
            }

            // 1) ADB
            try {
                ensureConnected(ctx)
                step("[1] ADB bağlantısı ✅")
            } catch (e: Exception) {
                step("[1] ADB bağlantısı ❌ ${e.javaClass.simpleName}: ${e.message}")
                step("    → Önce 'Eşle' ve 'Bağlan'/'Otomatik bağlan' adımlarını yap.")
                return fail()
            }

            // 2) Kabuk kullanıcısı
            val id = shell(ctx, "id").trim()
            step("[2] Kabuk kullanıcısı: ${id.ifEmpty { "(cevap yok)" }} " + if (id.contains("uid=2000")) "✅" else "⚠️")

            // 3) APK kabuk tarafından okunabiliyor mu?
            val apk = ctx.applicationInfo.sourceDir
            val ls = shell(ctx, "ls -l '$apk' 2>&1").trim()
            val apkOk = !ls.contains("No such file") && !ls.contains("denied") && ls.isNotEmpty()
            step("[3] APK ${if (apkOk) "✅" else "❌"}: ${ls.ifEmpty { "(cevap yok)" }}")
            if (!apkOk) return fail()

            // 4) Sunucuyu başlat (setsid varsa ayrı oturumda; çıktı günlüğe)
            val port = Prefs.port(ctx)
            val token = Prefs.token(ctx)
            val cmd = "rm -f $LOG; export CLASSPATH='$apk'; S=''; " +
                "command -v setsid >/dev/null 2>&1 && S=setsid; " +
                "\$S nohup app_process /system/bin --nice-name=km_injector " +
                "com.example.keymapper.shell.InjectorMain $port $token >$LOG 2>&1 </dev/null &"
            val launchOut = shell(ctx, cmd).trim()
            step("[4] Başlatma komutu gönderildi (port $port)" + if (launchOut.isNotEmpty()) " | çıktı: $launchOut" else "")

            // 5) Doğrulama döngüsü: bağlan -> API hazır mı -> ping. Süreç ölürse hemen nedenini oku.
            var tries = 0
            while (tries < 20) {
                tries++
                Thread.sleep(350)
                if (InjectorClient.connectBlocking(ctx)) {
                    if (!InjectorClient.injectOk) {
                        val log = shell(ctx, "cat $LOG 2>&1").trim()
                        step("[5] Sunucu açık ama dokunuş enjeksiyonu API'si bulunamadı ❌")
                        step("    Sunucu günlüğü: ${log.ifEmpty { "(boş)" }}")
                        return fail()
                    }
                    if (InjectorClient.ping()) {
                        step("[5] Soket + el sıkışma + ping ✅ (deneme $tries)")
                        return Pair(true, rep.toString().trim())
                    }
                    step("[5] Bağlandı ama ping başarısız ❌ ${InjectorClient.lastError}")
                    return fail()
                }
                if (tries >= 2 && tries % 2 == 0) {
                    val ps = shell(
                        ctx, "(ps -A -o PID,NAME,ARGS 2>/dev/null || ps -A) | grep -E 'km_injector|InjectorMain' | grep -v grep"
                    ).trim()
                    if (ps.isEmpty()) {
                        val log = shell(ctx, "cat $LOG 2>&1").trim()
                        step("[5] Sunucu süreci YOK (başlamadı veya çöktü) ❌")
                        step("    Sunucu günlüğü: ${log.ifEmpty { "(boş — süreç hiç çalışmamış olabilir)" }}")
                        step("    Son soket hatası: ${InjectorClient.lastError}")
                        return fail()
                    }
                }
            }
            // Zaman aşımı
            val ps = shell(ctx, "(ps -A -o PID,NAME,ARGS 2>/dev/null || ps -A) | grep -E 'km_injector|InjectorMain' | grep -v grep").trim()
            val log = shell(ctx, "cat $LOG 2>&1").trim()
            step("[5] Zaman aşımı ❌ Son soket hatası: ${InjectorClient.lastError}")
            step("    Süreç: ${ps.ifEmpty { "yok" }}")
            step("    Sunucu günlüğü: ${log.ifEmpty { "(boş)" }}")
            return fail()
        } catch (e: Exception) {
            Log.e(TAG, "startInjector hatası", e)
            step("HATA: ${e.javaClass.simpleName}: ${e.message}")
            return fail()
        }
    }
}
