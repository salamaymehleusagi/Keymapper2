package com.example.keymapper.core

import android.os.SystemClock
import android.view.MotionEvent
import com.example.keymapper.IInjector

/** Dokunuş verisini shell sürecindeki InjectorService'e gönderir; orada gerçek MotionEvent üretilir. */
class ShizukuTouchBackend(private val inj: IInjector) : TouchBackend {
    private val ids = ArrayList<Int>()
    private val pos = HashMap<Int, FloatArray>()
    private var downTime = 0L

    private fun send(action: Int) {
        val n = ids.size
        val idArr = IntArray(n) { ids[it] }
        val xs = FloatArray(n) { pos[ids[it]]!![0] }
        val ys = FloatArray(n) { pos[ids[it]]!![1] }
        try { inj.inject(action, downTime, idArr, xs, ys) } catch (_: Exception) {}
    }

    override fun down(id: Int, x: Float, y: Float) {
        if (ids.contains(id)) return
        ids.add(id); pos[id] = floatArrayOf(x, y)
        if (ids.size == 1) {
            downTime = SystemClock.uptimeMillis(); send(MotionEvent.ACTION_DOWN)
        } else {
            val idx = ids.indexOf(id)
            send(MotionEvent.ACTION_POINTER_DOWN or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT))
        }
    }

    override fun move(id: Int, x: Float, y: Float) {
        val p = pos[id] ?: return
        p[0] = x; p[1] = y
        send(MotionEvent.ACTION_MOVE)
    }

    override fun up(id: Int) {
        val idx = ids.indexOf(id)
        if (idx < 0) return
        if (ids.size == 1) send(MotionEvent.ACTION_UP)
        else send(MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT))
        ids.removeAt(idx); pos.remove(id)
    }
}
