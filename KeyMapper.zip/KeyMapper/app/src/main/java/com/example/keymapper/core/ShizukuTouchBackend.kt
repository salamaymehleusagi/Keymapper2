package com.example.keymapper.core

import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import com.example.keymapper.IInjector

/** Gerçek MotionEvent üreterek (shell yetkisiyle) çoklu dokunuş enjekte eder. Çok düşük gecikme. */
class ShizukuTouchBackend(private val inj: IInjector) : TouchBackend {
    private val ids = ArrayList<Int>()
    private val pos = HashMap<Int, FloatArray>()
    private var downTime = 0L

    private fun send(action: Int) {
        val n = ids.size
        val props = Array(n) { i ->
            MotionEvent.PointerProperties().apply { id = ids[i]; toolType = MotionEvent.TOOL_TYPE_FINGER }
        }
        val coords = Array(n) { i ->
            MotionEvent.PointerCoords().apply {
                x = pos[ids[i]]!![0]; y = pos[ids[i]]!![1]; pressure = 1f; size = 1f
            }
        }
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try { inj.inject(ev) } catch (_: Exception) {} finally { ev.recycle() }
    }

    override fun down(id: Int, x: Float, y: Float) {
        if (ids.contains(id)) return
        ids.add(id); pos[id] = floatArrayOf(x, y)
        if (ids.size == 1) {
            downTime = SystemClock.uptimeMillis(); send(MotionEvent.ACTION_DOWN)
        } else {
            val idx = ids.indexOf(id)
            send(MotionEvent.ACTION_POINTER_DOWN or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT))
        }
    }

    override fun move(id: Int, x: Float, y: Float) {
        val p = pos[id] ?: return
        p[0] = x; p[1] = y
        send(MotionEvent.ACTION_MOVE)
    }

    override fun up(id: Int) {
        val idx = ids.indexOf(id)
        if (idx < 0) return
        if (ids.size == 1) send(MotionEvent.ACTION_UP)
        else send(MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT))
        ids.removeAt(idx); pos.remove(id)
    }
}
