package com.example.keymapper.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import com.example.keymapper.model.Binding
import com.example.keymapper.model.ElementType
import com.example.keymapper.model.MacroStep
import com.example.keymapper.model.MappingElement
import com.example.keymapper.model.Profile
import kotlin.math.hypot

/**
 * Şeffaf düzenleme paneli (Overlay Mapping HUD).
 *  - Boş alana dokun        -> eleman ekle
 *  - Elemanın içini sürükle -> taşı
 *  - Elemanın kenarını sürükle -> boyutlandır
 *  - Elemana dokun          -> ayar penceresi (tuş, hassasiyet, sil ...)
 *  - SWIPE'ta uçtaki nokta  -> bitiş noktasını sürükle
 */
class EditorView(ctx: Context, var profile: Profile) : View(ctx) {

    var onEdit: ((MappingElement) -> Unit)? = null
    var onAdd: ((Float, Float) -> Unit)? = null
    var onRecordingDone: (() -> Unit)? = null
    /** Doluysa dokunuşlar bu makroya adım olarak kaydedilir. */
    var recording: MappingElement? = null

    private val dp = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * dp }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = 12f * dp
    }

    private var sel: MappingElement? = null
    private var mode = 0                      // 1 taşı, 2 boyutlandır, 3 swipe ucu
    private var sx = 0f; private var sy = 0f
    private var moved = false

    private fun minDim() = minOf(width, height).toFloat()

    private fun colorOf(t: ElementType) = when (t) {
        ElementType.BUTTON -> 0xFF2196F3.toInt()
        ElementType.JOYSTICK -> 0xFF4CAF50.toInt()
        ElementType.CAMERA -> 0xFFFF9800.toInt()
        ElementType.MACRO -> 0xFF9C27B0.toInt()
        ElementType.SWIPE -> 0xFF00BCD4.toInt()
        ElementType.LOCK_TOGGLE -> 0xFFF44336.toInt()
    }

    private fun labelOf(e: MappingElement) = when (e.type) {
        ElementType.JOYSTICK -> e.stick.label
        ElementType.CAMERA -> "CAM " + Binding.label(e.binding)
        ElementType.MACRO -> "M:" + Binding.label(e.binding)
        ElementType.SWIPE -> "SW:" + Binding.label(e.binding)
        ElementType.LOCK_TOGGLE -> "LOCK " + Binding.label(e.binding)
        else -> Binding.label(e.binding)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0x66000000)
        for (e in profile.elements) {
            val cx = e.x * width; val cy = e.y * height; val r = e.size * minDim()
            val col = colorOf(e.type)
            fill.color = col; fill.alpha = 70
            c.drawCircle(cx, cy, r, fill)
            line.color = col
            c.drawCircle(cx, cy, r, line)
            if (e.type == ElementType.JOYSTICK) c.drawCircle(cx, cy, r * 0.35f, line)
            if (e.type == ElementType.SWIPE) {
                val ex = e.x2 * width; val ey = e.y2 * height
                c.drawLine(cx, cy, ex, ey, line); c.drawCircle(ex, ey, 10f * dp, fill)
            }
            if (e.type == ElementType.MACRO) e.steps.forEachIndexed { i, s ->
                val px = s.x * width; val py = s.y * height
                c.drawCircle(px, py, 12f * dp, line)
                c.drawText("${i + 1}", px, py + txt.textSize / 3, txt)
            }
            c.drawText(labelOf(e), cx, cy + txt.textSize / 3, txt)
        }
        if (recording != null) {
            txt.textSize = 16f * dp
            c.drawText("Kayıt: noktalara dokun, bitirmek için makro simgesine dokun",
                width / 2f, height - 24f * dp, txt)
            txt.textSize = 12f * dp
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = ev.x; sy = ev.y; moved = false; sel = null; mode = 0
                val minHit = 28f * dp
                for (e in profile.elements.asReversed()) {
                    if (e.type == ElementType.SWIPE &&
                        hypot(ev.x - e.x2 * width, ev.y - e.y2 * height) < minHit) { sel = e; mode = 3; break }
                    val d = hypot(ev.x - e.x * width, ev.y - e.y * height)
                    val r = maxOf(e.size * minDim(), minHit)
                    if (d <= r) { sel = e; mode = if (d > r * 0.75f && e.size * minDim() > minHit) 2 else 1; break }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(ev.x - sx, ev.y - sy) > 10f * dp) moved = true
                val e = sel
                if (moved && e != null && recording == null) {
                    when (mode) {
                        1 -> { e.x = (ev.x / width).coerceIn(0f, 1f); e.y = (ev.y / height).coerceIn(0f, 1f) }
                        2 -> e.size = (hypot(ev.x - e.x * width, ev.y - e.y * height) / minDim()).coerceIn(0.02f, 0.5f)
                        3 -> { e.x2 = (ev.x / width).coerceIn(0f, 1f); e.y2 = (ev.y / height).coerceIn(0f, 1f) }
                    }
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> if (!moved) tap(ev.x, ev.y)
        }
        return true
    }

    private fun tap(x: Float, y: Float) {
        val rec = recording
        if (rec != null) {
            if (sel === rec) { recording = null; onRecordingDone?.invoke() }
            else rec.steps.add(MacroStep("TAP", x / width, y / height, 0f, 0f, 60))
            invalidate(); return
        }
        val e = sel
        if (e != null) onEdit?.invoke(e) else onAdd?.invoke(x / width, y / height)
    }
}
