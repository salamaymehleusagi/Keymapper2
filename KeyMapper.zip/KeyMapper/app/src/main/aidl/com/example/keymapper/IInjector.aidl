package com.example.keymapper;

// Shizuku UserService (shell yetkisi) arayüzü.
// MotionEvent yerine ilkel tipler geçilir (AIDL import sorunlarını önler).
interface IInjector {
    // Shizuku için zorunlu transaction numarası
    void destroy() = 16777114;
    boolean inject(int action, long downTime, in int[] ids, in float[] xs, in float[] ys);
}
