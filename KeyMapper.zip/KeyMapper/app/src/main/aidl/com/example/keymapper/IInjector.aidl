package com.example.keymapper;

import android.view.MotionEvent;

// Shizuku UserService (shell yetkisi) arayüzü
interface IInjector {
    // Shizuku için zorunlu transaction numarası
    void destroy() = 16777114;
    boolean inject(in MotionEvent event);
}
