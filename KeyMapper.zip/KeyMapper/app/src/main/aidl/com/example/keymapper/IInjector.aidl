package com.example.keymapper;

// Shizuku UserService (shell yetkisi) arayüzü.
// AIDL kuralı: bir metodun açık numarası varsa HEPSİNİN olmalı.
interface IInjector {
    // Shizuku için zorunlu transaction numarası
    void destroy() = 16777114;
    boolean inject(int action, long downTime, in int[] ids, in float[] xs, in float[] ys) = 1;
}
