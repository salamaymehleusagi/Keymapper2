# KeyMapper (Android, Kotlin)

Klavye + fare + gamepad girdilerini ekran dokunuşlarına çeviren, root gerektirmeyen keymapper.

## Derleme
1. Android Studio (Koala+) ile klasörü aç → Gradle sync (wrapper'ı kendisi oluşturur / JDK 17).
2. Terminal: `./gradlew assembleDebug`  →  `app/build/outputs/apk/debug/app-debug.apk`
   (veya `assembleRelease`: debug anahtarıyla imzalı, kurulabilir APK)

## Kurulum / kullanım
1. Uygulamayı aç → "Overlay izni" ver → "Erişilebilirlik" ayarlarından KeyMapper'ı aç.
2. (Opsiyonel, daha hızlı) Shizuku'yu Kablosuz Hata Ayıklama ile başlat → "Shizuku izni iste" → yöntem: Shizuku.
3. "Başlat" → ekranda 🎮 ikonu çıkar. Oyunu aç, ikona dokun → editör.
4. Boş alana dokun → eleman ekle (Tuş / Joystick / Kamera / Makro / Swipe / Lock tuşu).
   Elemana dokun → tuş ata, hassasiyet, boyut. Sürükle = taşı, kenarı sürükle = boyutlandır.
5. "▶ Oyna" → oyun modu. İkona dokunmak oyun modunu durdurup editöre döndürür.
6. "💾 Kaydet" profili kaydeder ve o anki oyunun paket adına bağlar (oyun açılınca otomatik yüklenir).
   Profiller ana ekrandan JSON olarak dışa/içe aktarılır.

## Mimari
- core/InputEngine      : tuş/fare/gamepad -> sanal parmaklar (joystick, kamera, makro, swipe, lock)
- core/A11yTouchBackend : dispatchGesture + continueStroke zinciri ile çoklu dokunuş
- core/ShizukuTouchBackend + service/InjectorService : shell yetkisiyle gerçek MotionEvent enjeksiyonu
- service/FloatingService : yüzen ikon, editör HUD, oyun modu, capture penceresi
- ui/CaptureView : 1x1 odaklanabilir/dokunulamaz pencere -> klavye, gamepad, Pointer Capture (fare)
- ui/EditorView  : şeffaf düzenleme paneli
